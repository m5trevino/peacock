#!/bin/bash
# Peacock Launcher - FIXED PATHS

echo "🦚 PEACOCK LAUNCHER - CORRECT PATHS"
echo "========================================"

TIMESTAMP=$(python3 -c "
import datetime
now = datetime.datetime.now()
week = now.isocalendar()[1]
day = now.day
hour = now.hour
minute = now.minute
print(f'{week}-{day}-{hour}{minute:02d}')
")

echo "📅 Session: $TIMESTAMP"
cd /home/flintx/peacock/core

# Step 1: Run 1prompt from core directory
echo "🚀 Generating 1PROMPT dashboard..."
python3 1prompt.py --timestamp "$TIMESTAMP"

# Step 2: Run xedit from core directory  
echo "🎯 Generating XEdit interface..."
python3 xedit.py --timestamp "$TIMESTAMP"

# Check files in html directory
DASHBOARD="/home/flintx/peacock/html/1prompt-dashboard-${TIMESTAMP}.html"
XEDIT="/home/flintx/peacock/html/xedit-${TIMESTAMP}.html"

echo "📂 Checking generated files..."
if [[ -f "$DASHBOARD" ]]; then
    echo "✅ Dashboard: $DASHBOARD"
else
    echo "❌ Dashboard missing"
fi

if [[ -f "$XEDIT" ]]; then
    echo "✅ XEdit: $XEDIT"
else  
    echo "❌ XEdit missing"
fi

# Open both if they exist
if [[ -f "$DASHBOARD" && -f "$XEDIT" ]]; then
    echo "🌐 Opening both interfaces..."
    xdg-open "$DASHBOARD" &
    sleep 1
    xdg-open "$XEDIT" &
    echo "🔥 PEACOCK IS LIVE!"
else
    echo "⚠️ Some files missing, check generation"
fi
