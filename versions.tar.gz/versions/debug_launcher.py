#!/usr/bin/env python3
"""
debug_launcher.py - Quick debug test for Peacock setup
"""

import sys
import os
from pathlib import Path

def test_peacock_setup():
    """Test the current Peacock setup"""
    print("🦚 PEACOCK SETUP DEBUG TEST")
    print("=" * 40)
    
    # Check Python version
    print(f"Python version: {sys.version}")
    print(f"Python executable: {sys.executable}")
    print()
    
    # Check current directory
    current_dir = Path.cwd()
    print(f"Current directory: {current_dir}")
    print()
    
    # Check peacock base directory
    peacock_base = Path("/home/flintx/peacock")
    print(f"Peacock base dir exists: {peacock_base.exists()}")
    
    if peacock_base.exists():
        print("Contents of /home/flintx/peacock:")
        for item in peacock_base.iterdir():
            print(f"  {item.name} ({'dir' if item.is_dir() else 'file'})")
    print()
    
    # Check core directory
    core_dir = peacock_base / "core"
    print(f"Core dir exists: {core_dir.exists()}")
    
    if core_dir.exists():
        print("Contents of /home/flintx/peacock/core:")
        for item in core_dir.iterdir():
            print(f"  {item.name} ({'dir' if item.is_dir() else 'file'})")
    print()
    
    # Check for key files
    key_files = [
        peacock_base / "moddash.py",
        peacock_base / "core" / "moddash.py", 
        peacock_base / "xedit.py",
        peacock_base / "core" / "xedit.py",
        peacock_base / "peacock_launcher.py"
    ]
    
    print("Key file status:")
    for file_path in key_files:
        exists = file_path.exists()
        size = file_path.stat().st_size if exists else 0
        print(f"  {file_path}: {'EXISTS' if exists else 'MISSING'} ({size} bytes)")
    print()
    
    # Test imports
    print("Testing imports:")
    
    # Try importing from core
    try:
        sys.path.insert(0, str(core_dir))
        import moddash
        print(f"  ✅ core/moddash.py imported successfully")
        
        # Test function
        if hasattr(moddash, 'generate_model_dashboard'):
            print(f"  ✅ generate_model_dashboard function found")
        else:
            print(f"  ❌ generate_model_dashboard function missing")
            
    except Exception as e:
        print(f"  ❌ Failed to import core/moddash.py: {e}")
    
    try:
        import xedit
        print(f"  ✅ core/xedit.py imported successfully")
        
        # Test function
        if hasattr(xedit, 'generate_xedit_interface'):
            print(f"  ✅ generate_xedit_interface function found")
        else:
            print(f"  ❌ generate_xedit_interface function missing")
            
    except Exception as e:
        print(f"  ❌ Failed to import core/xedit.py: {e}")
    
    print()
    
    # Test timestamp function
    try:
        import datetime
        now = datetime.datetime.now()
        week = now.isocalendar()[1]
        day = now.day
        hour = now.hour
        minute = now.minute
        session_timestamp = f"{week}-{day}-{hour}{minute:02d}"
        print(f"Generated session timestamp: {session_timestamp}")
    except Exception as e:
        print(f"❌ Failed to generate timestamp: {e}")
    
    print()
    print("=" * 40)
    print("🔍 Debug test complete!")

if __name__ == "__main__":
    test_peacock_setup()