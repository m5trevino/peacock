#!/usr/bin/env python3

import argparse
import datetime
import subprocess
import webbrowser
import time
import os
import sys
import requests
import json
from pathlib import Path

# PEACOCK CONFIGURATION
PEACOCK_BASE_DIR = Path("/home/flintx/peacock")
HTML_OUTPUT_DIR = PEACOCK_BASE_DIR / "html"
LOGS_DIR = PEACOCK_BASE_DIR / "logs"
PEACOCK_SERVER_URL = "http://127.0.0.1:8000/process"

def get_session_timestamp():
    """Get session timestamp matching peamcp.py format"""
    now = datetime.datetime.now()
    week = now.isocalendar()[1]
    day = now.day
    hour = now.hour
    minute = now.minute
    return f"{week}-{day}-{hour}{minute:02d}"

def cli_status(stage, status, message="", details=None):
    """Enhanced CLI status output with colors and timing"""
    timestamp = datetime.datetime.now().strftime("%H:%M:%S")
    
    colors = {
        "INFO": "\033[94m",      # Blue
        "WORKING": "\033[93m",   # Yellow
        "SUCCESS": "\033[92m",   # Green
        "ERROR": "\033[91m",     # Red
        "RESET": "\033[0m"       # Reset
    }
    
    icons = {
        "INFO": "ℹ️",
        "WORKING": "⚙️",
        "SUCCESS": "✅",
        "ERROR": "❌"
    }
    
    color = colors.get(status, "")
    icon = icons.get(status, "🔄")
    reset = colors["RESET"]
    
    print(f"{color}[{timestamp}] {icon} {stage}: {message}{reset}")
    
    if details:
        for detail in details if isinstance(details, list) else [details]:
            print(f"         └─ {detail}")
    
    sys.stdout.flush()

def check_peacock_server():
    """Check if Peacock server is running"""
    cli_status("SERVER CHECK", "INFO", "Checking Peacock server availability")
    
    try:
        response = requests.get("http://127.0.0.1:8000/health", timeout=5)
        if response.status_code == 200:
            health_data = response.json()
            cli_status("SERVER CHECK", "SUCCESS", f"Server online - Session: {health_data.get('session', 'unknown')}")
            return True
        else:
            cli_status("SERVER CHECK", "ERROR", f"Server returned status {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        cli_status("SERVER CHECK", "ERROR", "Server not reachable", str(e))
        return False

def run_peacock_pipeline(user_request):
    """Run the Peacock pipeline and get results"""
    cli_status("PIPELINE", "WORKING", f"Running pipeline for: {user_request[:50]}...")
    
    try:
        payload = {
            "command": "peacock_full",
            "text": user_request
        }
        
        response = requests.post(
            PEACOCK_SERVER_URL,
            json=payload,
            timeout=120  # 2 minutes for pipeline
        )
        
        if response.status_code == 200:
            result = response.json()
            
            if result.get("success"):
                cli_status("PIPELINE", "SUCCESS", "Pipeline completed successfully")
                return result
            else:
                cli_status("PIPELINE", "ERROR", "Pipeline failed", result.get("error", "Unknown error"))
                return None
        else:
            cli_status("PIPELINE", "ERROR", f"HTTP {response.status_code}", response.text[:100])
            return None
            
    except requests.exceptions.Timeout:
        cli_status("PIPELINE", "ERROR", "Pipeline timed out (2 minutes)")
        return None
    except Exception as e:
        cli_status("PIPELINE", "ERROR", "Unexpected error", str(e))
        return None

def extract_code_from_pipeline(pipeline_results):
    """Extract generated code from pipeline results"""
    cli_status("CODE EXTRACTION", "WORKING", "Extracting generated code from pipeline")
    
    try:
        # Get EAGLE stage results (implementation)
        eagle_results = pipeline_results.get("pipeline_results", {}).get("eagle", {})
        eagle_text = eagle_results.get("text", "")
        
        if not eagle_text:
            cli_status("CODE EXTRACTION", "ERROR", "No EAGLE implementation found")
            return None
        
        # Extract code content - EAGLE should have the actual generated files
        cli_status("CODE EXTRACTION", "SUCCESS", f"Extracted {len(eagle_text)} characters of generated code")
        return eagle_text
        
    except Exception as e:
        cli_status("CODE EXTRACTION", "ERROR", "Failed to extract code", str(e))
        return None

def check_dependencies():
    """Check if required dependencies are available"""
    cli_status("DEPENDENCY CHECK", "INFO", "Checking system requirements")
    
    # Check for xedit.py in multiple locations  
    xedit_locations = [
        PEACOCK_BASE_DIR / "core" / "xedit.py",
        PEACOCK_BASE_DIR / "xedit.py"
    ]
    
    xedit_found = any(loc.exists() for loc in xedit_locations)
    
    if not xedit_found:
        cli_status("DEPENDENCY CHECK", "ERROR", "xedit.py not found")
        return False
    
    # Check if browser is available
    try:
        webbrowser.get()
        cli_status("DEPENDENCY CHECK", "SUCCESS", "All dependencies satisfied")
        return True
    except webbrowser.Error:
        cli_status("DEPENDENCY CHECK", "ERROR", "No web browser found")
        return False

def create_directories():
    """Create required directories"""
    cli_status("SETUP", "INFO", "Creating required directories")
    
    directories = [HTML_OUTPUT_DIR, LOGS_DIR]
    created = []
    
    for directory in directories:
        if not directory.exists():
            directory.mkdir(parents=True, exist_ok=True)
            created.append(str(directory))
    
    if created:
        cli_status("SETUP", "SUCCESS", "Directories created", created)
    else:
        cli_status("SETUP", "INFO", "All directories already exist")

def generate_moddash_directly(session_timestamp):
    """Generate model dashboard directly (since moddash.py might be broken)"""
    cli_status("MODDASH", "WORKING", "Generating model dashboard")
    
    try:
        html_content = f'''<!DOCTYPE html>
<html>
<head>
    <title>🦚 Peacock Model Dashboard (Integrated)</title>
    <style>
        body {{ font-family: monospace; background: #0d1117; color: #e6edf3; padding: 20px; }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        .header {{ background: #161b22; border: 1px solid #30363d; padding: 20px; margin-bottom: 20px; }}
        .status {{ background: #238636; color: white; padding: 10px; margin: 10px 0; }}
        .model-card {{ background: #161b22; border: 1px solid #30363d; padding: 16px; margin: 10px 0; }}
        .model-name {{ color: #ff6b35; font-weight: bold; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🦚 Peacock Model Dashboard</h1>
            <div class="status">✅ Integrated Pipeline - Session: {session_timestamp}</div>
        </div>
        
        <div class="model-card">
            <div class="model-name">gemma2-9b-it</div>
            <p>Primary Model (Structure + Analysis)</p>
        </div>
        
        <div class="model-card">
            <div class="model-name">llama3-8b-8192</div>
            <p>Speed Model (Implementation)</p>
        </div>
        
        <div style="background: #161b22; border: 1px solid #30363d; padding: 20px; margin-top: 20px;">
            <h3>🚀 Integrated Pipeline Status</h3>
            <p>✅ Pipeline integration enabled</p>
            <p>✅ Automatic code extraction</p>
            <p>✅ XEdit populated with generated code</p>
        </div>
    </div>
</body>
</html>'''
        
        output_file = HTML_OUTPUT_DIR / f"moddash-{session_timestamp}.html"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        cli_status("MODDASH", "SUCCESS", f"Generated: {output_file}")
        return output_file
        
    except Exception as e:
        cli_status("MODDASH", "ERROR", f"Failed: {e}")
        return None

def generate_xedit(session_timestamp, code_content, project_name):
    """Generate XEdit interface with actual generated code"""
    cli_status("XEDIT", "WORKING", f"Generating XEdit interface for '{project_name}'")
    
    try:
        # Check for xedit.py in multiple locations
        xedit_script = PEACOCK_BASE_DIR / "core" / "xedit.py"
        if not xedit_script.exists():
            xedit_script = PEACOCK_BASE_DIR / "xedit.py"
        
        if not xedit_script.exists():
            cli_status("XEDIT", "ERROR", "xedit.py not found")
            return None
        
        # Add the directory containing xedit.py to Python path
        script_dir = str(xedit_script.parent)
        if script_dir not in sys.path:
            sys.path.insert(0, script_dir)
        
        try:
            import xedit
            import importlib
            importlib.reload(xedit)
        except ImportError as e:
            cli_status("XEDIT", "ERROR", f"Cannot import xedit module: {e}")
            return None
        
        # Generate the interface with the actual generated code
        html_content = xedit.generate_xedit_interface(code_content, project_name)
        
        # Save to file
        output_file = HTML_OUTPUT_DIR / f"xedit-{session_timestamp}.html"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        cli_status("XEDIT", "SUCCESS", f"Generated: {output_file}")
        cli_status("XEDIT", "INFO", f"XEdit populated with {len(code_content)} chars of generated code")
        return output_file
        
    except Exception as e:
        cli_status("XEDIT", "ERROR", "Generation failed", str(e))
        return None

def open_browser_tab(file_path, interface_name):
    """Open browser tab for the given HTML file"""
    if not file_path or not file_path.exists():
        cli_status("BROWSER", "ERROR", f"Cannot open {interface_name}")
        return False
    
    try:
        file_url = f"file://{file_path.absolute()}"
        cli_status("BROWSER", "WORKING", f"Opening {interface_name}")
        webbrowser.open_new_tab(file_url)
        time.sleep(1)
        cli_status("BROWSER", "SUCCESS", f"{interface_name} opened")
        return True
    except Exception as e:
        cli_status("BROWSER", "ERROR", f"Failed to open {interface_name}: {e}")
        return False

def print_summary(session_timestamp, moddash_file, xedit_file, project_name, pipeline_success):
    """Print final summary"""
    print("\n" + "🦚" + "="*68 + "🦚")
    print("    PEACOCK INTEGRATED LAUNCHER - SUMMARY")
    print("🦚" + "="*68 + "🦚")
    print()
    
    print(f"📝 Session: {session_timestamp}")
    print(f"🎯 Project: {project_name}")
    print(f"🚀 Pipeline: {'Success' if pipeline_success else 'Failed'}")
    print(f"📁 HTML Directory: {HTML_OUTPUT_DIR}")
    print()
    
    if moddash_file:
        print(f"✅ Model Dashboard: {moddash_file.name}")
        print(f"   └─ URL: file://{moddash_file.absolute()}")
    
    if xedit_file:
        print(f"✅ XEdit Interface: {xedit_file.name}")
        print(f"   └─ URL: file://{xedit_file.absolute()}")
        if pipeline_success:
            print(f"   └─ ✨ Populated with ACTUAL generated code")
    
    print()
    print("🌐 Browser tabs should be open with both interfaces")
    print("🔄 XEdit now shows the real generated project code!")
    print("="*70)

def main():
    """Main launcher function with pipeline integration"""
    parser = argparse.ArgumentParser(
        description='🦚 Peacock Integrated Launcher - Generate project and interfaces automatically'
    )
    parser.add_argument('--request', '-r', required=True,
                       help='Project request (e.g., "Build a snake game")')
    parser.add_argument('--project-name', '-n', 
                       help='Name of the project (auto-generated if not provided)')
    parser.add_argument('--no-browser', action='store_true',
                       help='Generate HTML files but do not open browser tabs')
    
    args = parser.parse_args()
    
    # Auto-generate project name if not provided
    if not args.project_name:
        args.project_name = f"Generated: {args.request[:30]}..."
    
    session_timestamp = get_session_timestamp()
    
    print("🦚" + "="*68 + "🦚")
    print("    PEACOCK INTEGRATED LAUNCHER")
    print("🦚" + "="*68 + "🦚")
    print(f"📝 Session: {session_timestamp}")
    print(f"🎯 Project: {args.project_name}")
    print(f"🚀 Request: {args.request}")
    print(f"🌐 Browser Launch: {'Disabled' if args.no_browser else 'Enabled'}")
    print("="*70)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Check if Peacock server is running
    if not check_peacock_server():
        cli_status("LAUNCHER", "ERROR", "Peacock server must be running")
        print("Start with: cd /home/flintx/peacock/core && python peamcp.py --log")
        sys.exit(1)
    
    # Create directories
    create_directories()
    
    # Run the pipeline to generate the actual project
    cli_status("INTEGRATION", "INFO", "Starting integrated pipeline workflow")
    pipeline_results = run_peacock_pipeline(args.request)
    
    if pipeline_results:
        # Extract the generated code from pipeline results
        generated_code = extract_code_from_pipeline(pipeline_results)
        
        if generated_code:
            # Use the actual generated code for XEdit
            code_content = generated_code
            pipeline_success = True
            cli_status("INTEGRATION", "SUCCESS", "Pipeline integration successful")
        else:
            # Fallback to basic content if extraction fails
            code_content = f"# Generated project: {args.project_name}\n# Request: {args.request}\n\n# Code extraction failed, but pipeline ran successfully"
            pipeline_success = False
            cli_status("INTEGRATION", "ERROR", "Code extraction failed")
    else:
        # Pipeline failed completely
        code_content = f"# Pipeline failed for: {args.request}\n# Please check server logs"
        pipeline_success = False
        cli_status("INTEGRATION", "ERROR", "Pipeline execution failed")
    
    # Generate interfaces
    cli_status("GENERATION", "INFO", "Generating interfaces")
    
    # Generate model dashboard
    moddash_file = generate_moddash_directly(session_timestamp)
    
    # Generate XEdit interface with the actual generated code
    xedit_file = generate_xedit(session_timestamp, code_content, args.project_name)
    
    # Open browser tabs if requested
    if not args.no_browser:
        cli_status("BROWSER", "INFO", "Opening browser tabs")
        
        if moddash_file:
            open_browser_tab(moddash_file, "Model Dashboard")
            
        if xedit_file:
            time.sleep(0.5)
            open_browser_tab(xedit_file, "XEdit Interface")
    
    # Print summary
    print_summary(session_timestamp, moddash_file, xedit_file, args.project_name, pipeline_success)
    
    # Exit with appropriate code
    if pipeline_success and xedit_file:
        cli_status("LAUNCHER", "SUCCESS", "Integrated pipeline completed successfully")
        return 0
    else:
        cli_status("LAUNCHER", "ERROR", "Pipeline integration had issues")
        return 1

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n🛑 Launcher stopped by user")
        sys.exit(130)
    except Exception as e:
        cli_status("LAUNCHER", "ERROR", "Unexpected error", str(e))
        sys.exit(1)