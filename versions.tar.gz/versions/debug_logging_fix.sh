# Debug the logging and quality validation issues

# 1. Check what prompt log files exist
echo "🔍 Checking for prompt log files:"
ls -la /home/flintx/peacock/logs/promptlog-*

# 2. Check the current session logs
echo ""
echo "📝 Current session logs:"
ls -la /home/flintx/peacock/logs/*23-7-*

# 3. Test quality validation manually
echo ""
echo "🧪 Testing quality validation logic..."

# 4. Create a debug version that shows what's failing
cat << 'EOF' > /home/flintx/peacock/core/debug_validation.py
#!/usr/bin/env python3
"""
Debug the quality validation issues
"""

import re
import json

def debug_validate_response_quality(response_content, command):
    """Debug version of quality validation"""
    print(f"🔍 Debugging validation for command: {command}")
    print(f"📝 Response length: {len(response_content)} chars")
    print(f"📋 First 200 chars: {response_content[:200]}...")
    
    # Check basic length
    if len(response_content.strip()) < 50:
        print("❌ FAILED: Response too short (< 50 chars)")
        return False
    else:
        print("✅ PASSED: Response length OK")
    
    # For structured commands, require JSON
    structured_commands = ["spark_analysis", "falcon_architecture", "eagle_implementation", "hawk_qa"]
    
    if command in structured_commands:
        print(f"🔍 Command '{command}' requires JSON validation")
        
        # Must contain valid JSON
        json_pattern = r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}'
        json_matches = re.findall(json_pattern, response_content, re.DOTALL)
        
        print(f"📊 Found {len(json_matches)} potential JSON blocks")
        
        for i, match in enumerate(json_matches):
            print(f"🧪 Testing JSON block {i+1}: {match[:100]}...")
            try:
                parsed = json.loads(match)
                print(f"✅ JSON block {i+1} is valid!")
                print(f"📋 Keys: {list(parsed.keys()) if isinstance(parsed, dict) else 'Not a dict'}")
                return True
            except Exception as e:
                print(f"❌ JSON block {i+1} failed: {e}")
                continue
        
        print("❌ FAILED: No valid JSON found")
        return False
    
    print("✅ PASSED: Non-structured command, no JSON required")
    return True

# Test with a sample EAGLE response
sample_response = """Here's the complete implementation:

**filename: index.html**
```html
<!DOCTYPE html>
<html>
<head>
    <title>Snake Game</title>
</head>
<body>
    <canvas id="gameCanvas"></canvas>
</body>
</html>
```

**filename: game.js**
```javascript
class SnakeGame {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
    }
}
```
"""

print("🧪 Testing sample EAGLE response:")
result = debug_validate_response_quality(sample_response, "eagle_implementation")
print(f"📊 Result: {result}")
EOF

# 5. Run the debug script
cd /home/flintx/peacock/core
python debug_validation.py

echo ""
echo "🔧 To fix the issues:"
echo "1. Check if EAGLE responses actually contain JSON (they might not need it)"
echo "2. Enable prompt logging in your server"
echo "3. Adjust quality validation for code generation vs analysis"