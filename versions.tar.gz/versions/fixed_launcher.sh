# Quick fix deployment commands

# 1. First, let's see what's in your broken launcher
echo "=== Current launcher content ==="
cat /home/flintx/peacock/peacock_launcher.py
echo ""

# 2. Deploy the working launcher to core directory (where your scripts are)
cat << 'EOF' > /home/flintx/peacock/core/peacock_launcher_fixed.py
#!/usr/bin/env python3
"""
peacock_launcher_fixed.py - Fixed Peacock Interface Launcher
Usage: python peacock_launcher_fixed.py [--code-file path] [--project-name "Name"] [--no-browser]
"""

import argparse
import datetime
import subprocess
import webbrowser
import time
import os
import sys
from pathlib import Path

# PEACOCK CONFIGURATION
PEACOCK_BASE_DIR = Path("/home/flintx/peacock")
CORE_DIR = PEACOCK_BASE_DIR / "core"
HTML_OUTPUT_DIR = PEACOCK_BASE_DIR / "html"
LOGS_DIR = PEACOCK_BASE_DIR / "logs"

def get_session_timestamp():
    """Get session timestamp matching peamcp.py format"""
    now = datetime.datetime.now()
    week = now.isocalendar()[1]
    day = now.day
    hour = now.hour
    minute = now.minute
    return f"{week}-{day}-{hour}{minute:02d}"

def cli_status(stage, status, message="", details=None):
    """Enhanced CLI status output with colors and timing"""
    timestamp = datetime.datetime.now().strftime("%H:%M:%S")
    
    colors = {
        "INFO": "\033[94m",      # Blue
        "WORKING": "\033[93m",   # Yellow
        "SUCCESS": "\033[92m",   # Green
        "ERROR": "\033[91m",     # Red
        "RESET": "\033[0m"       # Reset
    }
    
    icons = {
        "INFO": "ℹ️",
        "WORKING": "⚙️",
        "SUCCESS": "✅",
        "ERROR": "❌"
    }
    
    color = colors.get(status, "")
    icon = icons.get(status, "🔄")
    reset = colors["RESET"]
    
    print(f"{color}[{timestamp}] {icon} {stage}: {message}{reset}")
    
    if details:
        for detail in details if isinstance(details, list) else [details]:
            print(f"         └─ {detail}")
    
    sys.stdout.flush()

def check_dependencies():
    """Check if required dependencies are available"""
    cli_status("DEPENDENCY CHECK", "INFO", "Checking system requirements")
    
    # Check for files in core directory
    moddash_file = CORE_DIR / "moddash.py"
    xedit_file = CORE_DIR / "xedit.py"
    
    missing_files = []
    if not moddash_file.exists():
        missing_files.append(str(moddash_file))
    if not xedit_file.exists():
        missing_files.append(str(xedit_file))
    
    if missing_files:
        cli_status("DEPENDENCY CHECK", "ERROR", "Missing required files", missing_files)
        return False
    
    # Check if browser is available
    try:
        webbrowser.get()
        cli_status("DEPENDENCY CHECK", "SUCCESS", "Browser detection successful")
    except webbrowser.Error:
        cli_status("DEPENDENCY CHECK", "ERROR", "No web browser found")
        return False
    
    cli_status("DEPENDENCY CHECK", "SUCCESS", "All dependencies satisfied")
    return True

def create_directories():
    """Create required directories"""
    cli_status("SETUP", "INFO", "Creating required directories")
    
    directories = [HTML_OUTPUT_DIR, LOGS_DIR]
    created = []
    
    for directory in directories:
        if not directory.exists():
            directory.mkdir(parents=True, exist_ok=True)
            created.append(str(directory))
    
    if created:
        cli_status("SETUP", "SUCCESS", "Directories created", created)
    else:
        cli_status("SETUP", "INFO", "All directories already exist")

def load_sample_code(code_file=None):
    """Load code content from file or use default sample"""
    if code_file and Path(code_file).exists():
        cli_status("CODE LOADING", "INFO", f"Loading code from {code_file}")
        try:
            with open(code_file, 'r', encoding='utf-8') as f:
                content = f.read()
            cli_status("CODE LOADING", "SUCCESS", f"Loaded {len(content)} characters")
            return content
        except Exception as e:
            cli_status("CODE LOADING", "ERROR", f"Failed to load {code_file}", str(e))
            return get_default_sample_code()
    else:
        cli_status("CODE LOADING", "INFO", "Using default sample code")
        return get_default_sample_code()

def get_default_sample_code():
    """Get default sample code for demonstration"""
    return '''#!/usr/bin/env python3
"""
Peacock Generated Application - Multi-Model Optimized
"""

def main():
    print("🦚 Peacock Generated App")
    calculator = Calculator()
    calculator.run()

class Calculator:
    def __init__(self):
        self.result = 0
        self.history = []
    
    def run(self):
        print("Calculator started")
        # Enhanced logic
        
    def add(self, a, b):
        return a + b
        
    def multiply(self, a, b):
        return a * b

def validate_input(value):
    """Input validation function"""
    try:
        return float(value)
    except ValueError:
        return None

if __name__ == "__main__":
    main()'''

def generate_moddash_directly(session_timestamp):
    """Generate model dashboard directly (bypass broken function)"""
    cli_status("MODDASH", "WORKING", "Generating model dashboard directly")
    
    try:
        # Direct generation since the function is missing
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🦚 Peacock Model Dashboard (Fixed)</title>
    <style>
        body {{ font-family: 'SF Mono', monospace; background: #0d1117; color: #e6edf3; padding: 20px; }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        .header {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 20px; margin-bottom: 20px; }}
        .status {{ background: #238636; color: white; padding: 10px; border-radius: 6px; margin: 10px 0; }}
        .model-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 16px; }}
        .model-card {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 16px; }}
        .model-name {{ color: #ff6b35; font-weight: bold; margin-bottom: 8px; }}
        .model-status {{ color: #238636; font-size: 12px; }}
        .chat-container {{ background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 20px; margin-top: 20px; }}
        .chat-input {{ width: 100%; padding: 12px; background: #0d1117; border: 1px solid #30363d; border-radius: 6px; color: #e6edf3; margin-bottom: 10px; }}
        .chat-btn {{ background: #238636; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🦚 Peacock Model Dashboard</h1>
            <div class="status">✅ Fixed Version - Session: {session_timestamp}</div>
            <p>Multi-Model Strategy Enabled</p>
        </div>
        
        <div class="model-grid">
            <div class="model-card">
                <div class="model-name">gemma2-9b-it</div>
                <div class="model-status">Primary Model (Structure Champion)</div>
                <p>Best for SPARK analysis and FALCON architecture</p>
            </div>
            
            <div class="model-card">
                <div class="model-name">llama3-8b-8192</div>
                <div class="model-status">Speed Model (0.43-0.97s)</div>
                <p>Best for EAGLE implementation and explanations</p>
            </div>
            
            <div class="model-card">
                <div class="model-name">llama-3.1-8b-instant</div>
                <div class="model-status">Fallback Model</div>
                <p>Reliable backup for all stages</p>
            </div>
        </div>
        
        <div class="chat-container">
            <h3>💬 Quick Build Interface</h3>
            <input type="text" class="chat-input" placeholder="Build a snake game..." id="promptInput">
            <button class="chat-btn" onclick="sendToPeacock()">Send to Optimized Pipeline</button>
            <div id="output" style="margin-top: 15px; padding: 10px; background: #0d1117; border-radius: 6px; min-height: 50px;"></div>
        </div>
    </div>
    
    <script>
        function sendToPeacock() {{
            const input = document.getElementById('promptInput');
            const output = document.getElementById('output');
            const prompt = input.value.trim();
            
            if (!prompt) return;
            
            output.innerHTML = '<div style="color: #238636;">🦚 Sending to optimized pipeline...</div>';
            
            fetch('http://127.0.0.1:8000/process', {{
                method: 'POST',
                headers: {{ 'Content-Type': 'application/json' }},
                body: JSON.stringify({{
                    command: 'peacock_full',
                    text: prompt
                }})
            }})
            .then(response => response.json())
            .then(data => {{
                if (data.success) {{
                    output.innerHTML = '<div style="color: #238636;">✅ Pipeline completed successfully!</div>';
                }} else {{
                    output.innerHTML = '<div style="color: #da3633;">❌ Error: ' + (data.error || 'Unknown error') + '</div>';
                }}
            }})
            .catch(error => {{
                output.innerHTML = '<div style="color: #da3633;">❌ Connection error: ' + error.message + '</div>';
            }});
        }}
        
        document.getElementById('promptInput').addEventListener('keypress', function(e) {{
            if (e.key === 'Enter') {{
                sendToPeacock();
            }}
        }});
    </script>
</body>
</html>"""
        
        # Save to file
        output_file = HTML_OUTPUT_DIR / f"moddash-{session_timestamp}.html"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        cli_status("MODDASH", "SUCCESS", f"Generated: {output_file}")
        return output_file
        
    except Exception as e:
        cli_status("MODDASH", "ERROR", "Direct generation failed", str(e))
        return None

def generate_xedit(session_timestamp, code_content, project_name):
    """Generate XEdit interface"""
    cli_status("XEDIT", "WORKING", f"Generating XEdit interface for '{project_name}'")
    
    try:
        # Add core directory to Python path
        sys.path.insert(0, str(CORE_DIR))
        
        # Import xedit module
        import xedit
        import importlib
        importlib.reload(xedit)
        
        # Generate the interface
        html_content = xedit.generate_xedit_interface(code_content, project_name)
        
        # Save to file
        output_file = HTML_OUTPUT_DIR / f"xedit-{session_timestamp}.html"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        cli_status("XEDIT", "SUCCESS", f"Generated: {output_file}")
        return output_file
        
    except Exception as e:
        cli_status("XEDIT", "ERROR", "Generation failed", str(e))
        return None

def open_browser_tab(file_path, interface_name):
    """Open browser tab for the given HTML file"""
    if not file_path or not file_path.exists():
        cli_status("BROWSER", "ERROR", f"Cannot open {interface_name}: File not found")
        return False
    
    try:
        file_url = f"file://{file_path.absolute()}"
        cli_status("BROWSER", "WORKING", f"Opening {interface_name} in browser")
        
        webbrowser.open_new_tab(file_url)
        time.sleep(1)
        
        cli_status("BROWSER", "SUCCESS", f"{interface_name} opened successfully")
        return True
        
    except Exception as e:
        cli_status("BROWSER", "ERROR", f"Failed to open {interface_name}", str(e))
        return False

def print_summary(session_timestamp, moddash_file, xedit_file, project_name):
    """Print final summary"""
    print("\n" + "🦚" + "="*68 + "🦚")
    print("    PEACOCK INTERFACE LAUNCHER - SUMMARY (FIXED)")
    print("🦚" + "="*68 + "🦚")
    print()
    
    print(f"📝 Session: {session_timestamp}")
    print(f"🎯 Project: {project_name}")
    print(f"📁 HTML Directory: {HTML_OUTPUT_DIR}")
    print()
    
    if moddash_file:
        print(f"✅ Model Dashboard: {moddash_file.name}")
        print(f"   └─ URL: file://{moddash_file.absolute()}")
    else:
        print("❌ Model Dashboard: Generation failed")
    
    if xedit_file:
        print(f"✅ XEdit Interface: {xedit_file.name}")
        print(f"   └─ URL: file://{xedit_file.absolute()}")
    else:
        print("❌ XEdit Interface: Generation failed")
    
    print()
    print("🌐 Browser tabs should now be open with both interfaces")
    print("🔄 To regenerate, run: python peacock_launcher_fixed.py")
    print("="*70)

def main():
    """Main launcher function"""
    parser = argparse.ArgumentParser(
        description='🦚 Peacock Interface Launcher (Fixed Version)'
    )
    parser.add_argument('--code-file', '-f', 
                       help='Path to code file to analyze')
    parser.add_argument('--project-name', '-n', default='Peacock Generated Project',
                       help='Name of the project')
    parser.add_argument('--no-browser', action='store_true',
                       help='Generate HTML files but do not open browser tabs')
    
    args = parser.parse_args()
    
    session_timestamp = get_session_timestamp()
    
    print("🦚" + "="*68 + "🦚")
    print("    PEACOCK INTERFACE LAUNCHER (FIXED VERSION)")
    print("🦚" + "="*68 + "🦚")
    print(f"📝 Session: {session_timestamp}")
    print(f"🎯 Project: {args.project_name}")
    print(f"🌐 Browser Launch: {'Disabled' if args.no_browser else 'Enabled'}")
    print("="*70)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Create directories
    create_directories()
    
    # Load code content
    code_content = load_sample_code(args.code_file)
    
    # Generate interfaces
    cli_status("GENERATION", "INFO", "Starting interface generation")
    
    # Generate model dashboard (using direct method)
    moddash_file = generate_moddash_directly(session_timestamp)
    
    # Generate XEdit interface  
    xedit_file = generate_xedit(session_timestamp, code_content, args.project_name)
    
    # Open browser tabs if requested
    if not args.no_browser:
        cli_status("BROWSER", "INFO", "Opening browser tabs")
        
        if moddash_file:
            open_browser_tab(moddash_file, "Model Dashboard")
            
        if xedit_file:
            time.sleep(0.5)
            open_browser_tab(xedit_file, "XEdit Interface")
    
    # Print summary
    print_summary(session_timestamp, moddash_file, xedit_file, args.project_name)
    
    # Exit with appropriate code
    success_count = sum([bool(moddash_file), bool(xedit_file)])
    if success_count == 2:
        cli_status("LAUNCHER", "SUCCESS", "All interfaces generated successfully")
        return 0
    elif success_count == 1:
        cli_status("LAUNCHER", "INFO", "Partial success - some interfaces failed")
        return 1
    else:
        cli_status("LAUNCHER", "ERROR", "All interface generation failed")
        return 2

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n🛑 Launcher stopped by user")
        sys.exit(130)
    except Exception as e:
        cli_status("LAUNCHER", "ERROR", "Unexpected error", str(e))
        sys.exit(1)
EOF

# 3. Make it executable
chmod +x /home/flintx/peacock/core/peacock_launcher_fixed.py

# 4. Test the fixed launcher
cd /home/flintx/peacock/core
python peacock_launcher_fixed.py

# 5. Test with custom project name
python peacock_launcher_fixed.py --project-name "My Fixed Calculator"

# 6. Create a simple alias for the working launcher
echo 'alias peacock-fixed="cd /home/flintx/peacock/core && python peacock_launcher_fixed.py"' >> ~/.zshrc