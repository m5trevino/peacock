#!/usr/bin/env python3
"""
moddash.py - Peacock Model Dashboard Generator (Optimized Version)
"""

import json
import subprocess
import requests
import datetime
from pathlib import Path

# PEACOCK MULTI-MODEL STRATEGY
PEACOCK_MODEL_STRATEGY = {
    "primary_model": "gemma2-9b-it",        # Best overall mixed content
    "speed_model": "llama3-8b-8192",        # When speed is critical  
    "explanation_model": "llama3-8b-8192",  # When detailed explanations needed
    "json_model": "llama3-8b-8192",         # Most reliable JSON parsing
    "fallback_model": "llama-3.1-8b-instant"
}

# STAGE-SPECIFIC MODEL ASSIGNMENT
PEACOCK_STAGE_MODELS = {
    "spark_analysis": "gemma2-9b-it",      # Structure + requirements
    "falcon_architecture": "gemma2-9b-it", # Won architecture tests
    "eagle_implementation": "llama3-8b-8192", # Speed + explanations  
    "hawk_qa": "gemma2-9b-it",             # Structure + organization
    "code_analysis": "llama3-8b-8192"      # Speed + perfect JSON
}

# MODEL PERFORMANCE METRICS (From test results)
MODEL_METRICS = {
    "gemma2-9b-it": {
        "score": 114,
        "max_score": 150,
        "percentage": 76,
        "strengths": ["Structure", "JSON", "Code"],
        "weakness": "Explanations",
        "response_time": "1.20-2.51s",
        "specialty": "Mixed Content Champion"
    },
    "llama3-8b-8192": {
        "score": 112,
        "max_score": 150,
        "percentage": 75,
        "strengths": ["Speed", "Perfect JSON", "Explanations"],
        "weakness": "Structure",
        "response_time": "0.43-0.97s",
        "specialty": "Speed King"
    },
    "llama-3.1-8b-instant": {
        "score": 100,
        "max_score": 150,
        "percentage": 67,
        "strengths": ["Reliable JSON", "Good Code"],
        "weakness": "Poor Explanations",
        "response_time": "0.93-2.45s",
        "specialty": "Reliable Fallback"
    }
}