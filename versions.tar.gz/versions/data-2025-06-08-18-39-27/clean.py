#!/usr/bin/env python3
"""
JSON Message Content Cleaner - Clean up JSON with escaped content
Specifically designed for chat message JSON with escaped text content
"""

import json
import sys
import re
from pathlib import Path
import datetime

class JSONMessageCleaner:
    def __init__(self):
        self.output_dir = "cleaned_json_messages"
        Path(self.output_dir).mkdir(exist_ok=True)
    
    def clean_text_content(self, text):
        """Clean up escaped text content to make it human readable"""
        if not isinstance(text, str):
            return text
        
        # Unescape common escape sequences
        text = text.replace('\\n', '\n')
        text = text.replace('\\t', '\t')
        text = text.replace('\\r', '\r')
        text = text.replace('\\"', '"')
        text = text.replace("\\'", "'")
        text = text.replace('\\\\', '\\')
        
        # Handle Unicode escape sequences
        text = re.sub(r'\\u([0-9a-fA-F]{4})', lambda m: chr(int(m.group(1), 16)), text)
        
        # Clean up excessive whitespace but preserve intentional formatting
        text = re.sub(r'\n\s*\n\s*\n+', '\n\n', text)
        text = re.sub(r'[ \t]+', ' ', text)
        
        return text.strip()
    
    def process_json_recursively(self, obj):
        """Recursively process JSON object to clean text content"""
        if isinstance(obj, dict):
            cleaned = {}
            for key, value in obj.items():
                if key == "text" and isinstance(value, str):
                    # Special handling for text content
                    cleaned[key] = self.clean_text_content(value)
                else:
                    cleaned[key] = self.process_json_recursively(value)
            return cleaned
        
        elif isinstance(obj, list):
            return [self.process_json_recursively(item) for item in obj]
        
        elif isinstance(obj, str):
            # Clean any string that looks like it has escape sequences
            if '\\n' in obj or '\\t' in obj or '\\u' in obj:
                return self.clean_text_content(obj)
            return obj
        
        else:
            return obj
    
    def extract_message_info(self, data):
        """Extract key information from message data"""
        info = {
            "total_messages": 0,
            "senders": set(),
            "timestamps": [],
            "content_types": set(),
            "has_attachments": False,
            "has_citations": False
        }
        
        def analyze_recursive(obj):
            if isinstance(obj, dict):
                # Count messages
                if "uuid" in obj and "text" in obj:
                    info["total_messages"] += 1
                
                # Track senders
                if "sender" in obj:
                    info["senders"].add(obj["sender"])
                
                # Track timestamps
                if "created_at" in obj:
                    info["timestamps"].append(obj["created_at"])
                
                # Track content types
                if "type" in obj:
                    info["content_types"].add(obj["type"])
                
                # Check for attachments
                if "attachments" in obj and obj["attachments"]:
                    info["has_attachments"] = True
                
                # Check for citations
                if "citations" in obj and obj["citations"]:
                    info["has_citations"] = True
                
                # Recurse into nested objects
                for value in obj.values():
                    analyze_recursive(value)
            
            elif isinstance(obj, list):
                for item in obj:
                    analyze_recursive(item)
        
        analyze_recursive(data)
        
        # Convert sets to lists for JSON serialization
        info["senders"] = list(info["senders"])
        info["content_types"] = list(info["content_types"])
        
        return info
    
    def generate_readable_html(self, original_data, cleaned_data, filename="json_messages"):
        """Generate human-readable HTML report"""
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Extract message information
        message_info = self.extract_message_info(cleaned_data)
        
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🦚 Cleaned JSON Messages: {filename}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ 
            font-family: 'SF Mono', 'Monaco', 'Cascadia Code', monospace; 
            background: #0d1117; 
            color: #e6edf3; 
            padding: 20px; 
            line-height: 1.6;
        }}
        
        .header {{ 
            background: #161b22; 
            border: 1px solid #30363d; 
            border-radius: 8px; 
            padding: 20px; 
            margin-bottom: 20px; 
        }}
        
        .title {{ 
            color: #ff6b35; 
            font-size: 24px; 
            font-weight: bold; 
            margin-bottom: 10px; 
        }}
        
        .stats {{ 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); 
            gap: 10px; 
            margin-top: 15px; 
        }}
        
        .stat-item {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            border-radius: 6px; 
            padding: 10px; 
            text-align: center; 
        }}
        
        .stat-number {{ 
            color: #00ff88; 
            font-size: 18px; 
            font-weight: bold; 
        }}
        
        .stat-label {{ 
            color: #8b949e; 
            font-size: 12px; 
            text-transform: uppercase; 
        }}
        
        .section {{ 
            background: #161b22; 
            border: 1px solid #30363d; 
            border-radius: 8px; 
            padding: 20px; 
            margin-bottom: 20px; 
        }}
        
        .section-title {{ 
            color: #00ff88; 
            font-size: 18px; 
            font-weight: bold; 
            margin-bottom: 15px; 
            border-bottom: 1px solid #30363d; 
            padding-bottom: 5px; 
        }}
        
        .json-container {{ 
            background: #0d1117; 
            border: 1px solid #30363d; 
            border-radius: 6px; 
            padding: 15px; 
            white-space: pre-wrap; 
            overflow-x: auto; 
            max-height: 600px; 
            overflow-y: auto; 
            font-size: 13px; 
        }}
        
        .text-content {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            border-radius: 6px; 
            padding: 15px; 
            margin: 10px 0; 
            white-space: pre-wrap; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            line-height: 1.5; 
        }}
        
        .message-item {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            border-radius: 6px; 
            padding: 15px; 
            margin: 10px 0; 
        }}
        
        .message-header {{ 
            color: #79c0ff; 
            font-weight: bold; 
            margin-bottom: 8px; 
            border-bottom: 1px solid #30363d; 
            padding-bottom: 5px; 
        }}
        
        .message-text {{ 
            background: #0d1117; 
            border: 1px solid #30363d; 
            border-radius: 4px; 
            padding: 10px; 
            margin: 8px 0; 
            white-space: pre-wrap; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
        }}
        
        .controls {{ 
            margin-bottom: 15px; 
            display: flex; 
            gap: 10px; 
            flex-wrap: wrap; 
        }}
        
        .btn {{ 
            background: #238636; 
            border: none; 
            color: white; 
            padding: 8px 16px; 
            border-radius: 6px; 
            cursor: pointer; 
            font-size: 12px; 
            font-weight: 600; 
        }}
        
        .btn:hover {{ background: #2ea043; }}
        .btn.secondary {{ background: #21262d; border: 1px solid #30363d; }}
        .btn.secondary:hover {{ background: #30363d; }}
        
        .search-box {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            color: #e6edf3; 
            padding: 8px 12px; 
            border-radius: 6px; 
            font-size: 12px; 
        }}
        
        .highlight {{ background: #ffd33d; color: #0d1117; }}
        
        .info-list {{ 
            list-style: none; 
        }}
        
        .info-list li {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            border-radius: 4px; 
            padding: 8px 12px; 
            margin: 5px 0; 
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="title">🦚 Cleaned JSON Messages</div>
        <div><strong>File:</strong> {filename}</div>
        <div><strong>Generated:</strong> {timestamp}</div>
        <div><strong>Original Size:</strong> {len(str(original_data))} characters</div>
        <div><strong>Cleaned Size:</strong> {len(str(cleaned_data))} characters</div>
        
        <div class="stats">
            <div class="stat-item">
                <div class="stat-number">{message_info['total_messages']}</div>
                <div class="stat-label">Messages</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{len(message_info['senders'])}</div>
                <div class="stat-label">Senders</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{len(message_info['content_types'])}</div>
                <div class="stat-label">Content Types</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{'Yes' if message_info['has_attachments'] else 'No'}</div>
                <div class="stat-label">Attachments</div>
            </div>
        </div>
    </div>"""
        
        # Add message overview
        if message_info['senders']:
            html_content += f"""
    <div class="section">
        <div class="section-title">👥 Senders ({len(message_info['senders'])})</div>
        <ul class="info-list">"""
            for sender in message_info['senders']:
                html_content += f"<li>{sender}</li>"
            html_content += "</ul></div>"
        
        if message_info['content_types']:
            html_content += f"""
    <div class="section">
        <div class="section-title">📝 Content Types ({len(message_info['content_types'])})</div>
        <ul class="info-list">"""
            for content_type in message_info['content_types']:
                html_content += f"<li>{content_type}</li>"
            html_content += "</ul></div>"
        
        # Add readable messages section
        html_content += f"""
    <div class="section">
        <div class="section-title">💬 Readable Messages</div>
        <div class="controls">
            <button class="btn" onclick="showMessages()">📖 Show Messages</button>
            <button class="btn secondary" onclick="showJSON()">📋 Show JSON</button>
            <input type="text" class="search-box" placeholder="Search messages..." onkeyup="searchContent(this.value)">
        </div>
        
        <div id="messages-view">"""
        
        # Extract and display readable messages
        def extract_messages(obj, messages=None):
            if messages is None:
                messages = []
            
            if isinstance(obj, dict):
                if "text" in obj and "sender" in obj:
                    messages.append({
                        "text": obj.get("text", ""),
                        "sender": obj.get("sender", "unknown"),
                        "created_at": obj.get("created_at", ""),
                        "uuid": obj.get("uuid", "")
                    })
                
                for value in obj.values():
                    extract_messages(value, messages)
            
            elif isinstance(obj, list):
                for item in obj:
                    extract_messages(item, messages)
            
            return messages
        
        messages = extract_messages(cleaned_data)
        
        for i, msg in enumerate(messages):
            sender = msg['sender']
            text = msg['text']
            timestamp = msg['created_at']
            
            html_content += f"""
            <div class="message-item">
                <div class="message-header">
                    Message {i+1} • {sender} • {timestamp[:19] if timestamp else 'No timestamp'}
                </div>
                <div class="message-text">{text}</div>
            </div>"""
        
        html_content += """
        </div>
        
        <div id="json-view" style="display: none;">
            <div class="json-container">"""
        
        html_content += json.dumps(cleaned_data, indent=2, ensure_ascii=False)
        
        html_content += """</div>
        </div>
    </div>

    <script>
        function showMessages() {
            document.getElementById('messages-view').style.display = 'block';
            document.getElementById('json-view').style.display = 'none';
        }
        
        function showJSON() {
            document.getElementById('messages-view').style.display = 'none';
            document.getElementById('json-view').style.display = 'block';
        }
        
        function searchContent(query) {
            const messages = document.querySelectorAll('.message-text');
            messages.forEach(msg => {
                const text = msg.textContent.toLowerCase();
                const parent = msg.closest('.message-item');
                
                if (query.trim() === '' || text.includes(query.toLowerCase())) {
                    parent.style.display = 'block';
                } else {
                    parent.style.display = 'none';
                }
            });
        }
        
        // Raw data for console access
        const cleanedData = """ + json.dumps(cleaned_data) + """;
        console.log('Cleaned JSON data available as cleanedData variable');
    </script>
</body>
</html>"""
        
        # Save HTML file
        html_file = f"{self.output_dir}/{filename}_readable_{timestamp}.html"
        with open(html_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return html_file
    
    def generate_clean_text(self, cleaned_data, filename="json_messages"):
        """Generate clean text version"""
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        
        def extract_text_content(obj, texts=None):
            if texts is None:
                texts = []
            
            if isinstance(obj, dict):
                if "text" in obj and obj["text"].strip():
                    sender = obj.get("sender", "unknown")
                    timestamp = obj.get("created_at", "")
                    text = obj["text"]
                    
                    texts.append(f"[{sender}] {timestamp[:19] if timestamp else 'No timestamp'}")
                    texts.append(text)
                    texts.append("-" * 50)
                
                for value in obj.values():
                    extract_text_content(value, texts)
            
            elif isinstance(obj, list):
                for item in obj:
                    extract_text_content(item, texts)
            
            return texts
        
        text_content = extract_text_content(cleaned_data)
        
        text_file = f"{self.output_dir}/{filename}_readable_{timestamp}.txt"
        with open(text_file, 'w', encoding='utf-8') as f:
            f.write("🦚 PEACOCK JSON MESSAGES - READABLE TEXT\n")
            f.write("=" * 60 + "\n\n")
            f.write("\n".join(text_content))
        
        return text_file
    
    def process_json_file(self, file_path):
        """Process JSON file and generate cleaned versions"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                original_data = json.load(f)
        except Exception as e:
            print(f"❌ Error reading JSON file: {e}")
            return None
        
        print(f"📄 Processing: {file_path}")
        print(f"📏 Original size: {len(str(original_data))} characters")
        
        # Clean the JSON data
        cleaned_data = self.process_json_recursively(original_data)
        
        filename = Path(file_path).stem
        
        # Generate outputs
        html_file = self.generate_readable_html(original_data, cleaned_data, filename)
        text_file = self.generate_clean_text(cleaned_data, filename)
        
        # Save cleaned JSON
        json_file = f"{self.output_dir}/{filename}_cleaned_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(cleaned_data, f, indent=2, ensure_ascii=False)
        
        return {
            "html_file": html_file,
            "text_file": text_file,
            "json_file": json_file,
            "original_size": len(str(original_data)),
            "cleaned_size": len(str(cleaned_data))
        }

def main():
    cleaner = JSONMessageCleaner()
    
    print("🦚 PEACOCK JSON MESSAGE CLEANER")
    print("=" * 50)
    
    if len(sys.argv) != 2:
        print("Usage: python3 clean_json_messages.py <json_file>")
        print("Example: python3 clean_json_messages.py messages.json")
        sys.exit(1)
    
    file_path = sys.argv[1]
    
    if not Path(file_path).exists():
        print(f"❌ File not found: {file_path}")
        sys.exit(1)
    
    # Process the file
    result = cleaner.process_json_file(file_path)
    
    if result:
        print(f"\n✅ CLEANING COMPLETE!")
        print(f"   📄 HTML Report: {result['html_file']}")
        print(f"   📝 Text Version: {result['text_file']}")
        print(f"   📋 Cleaned JSON: {result['json_file']}")
        print(f"   📏 Size reduction: {result['original_size']} → {result['cleaned_size']} chars")
        
        # Try to open HTML file
        try:
            import webbrowser
            import os
            webbrowser.open(f"file://{os.path.abspath(result['html_file'])}")
            print(f"\n🌐 Opening HTML report in browser...")
        except Exception as e:
            print(f"\n⚠️  Could not open browser: {e}")
        
        print(f"\n🎉 JSON message cleaning complete!")
    else:
        print(f"\n❌ Failed to process file")

if __name__ == "__main__":
    main()