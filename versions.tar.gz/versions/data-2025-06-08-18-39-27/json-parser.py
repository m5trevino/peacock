#!/usr/bin/env python3
"""
JSON Parser Script - Convert JSON files to human-readable format
Handles nested structures, arrays, and creates clean HTML output
"""

import json
import sys
import os
from pathlib import Path
import datetime

class JSONParser:
    def __init__(self):
        self.output_dir = "parsed_json_output"
        self.ensure_output_dir()
    
    def ensure_output_dir(self):
        """Create output directory if it doesn't exist"""
        Path(self.output_dir).mkdir(exist_ok=True)
    
    def parse_json_file(self, json_file_path):
        """Parse JSON file and return structured data"""
        try:
            with open(json_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return {"success": True, "data": data}
        except json.JSONDecodeError as e:
            return {"success": False, "error": f"JSON decode error: {e}"}
        except FileNotFoundError:
            return {"success": False, "error": f"File not found: {json_file_path}"}
        except Exception as e:
            return {"success": False, "error": f"Unexpected error: {e}"}
    
    def parse_json_string(self, json_string):
        """Parse JSON string and return structured data"""
        try:
            data = json.loads(json_string)
            return {"success": True, "data": data}
        except json.JSONDecodeError as e:
            return {"success": False, "error": f"JSON decode error: {e}"}
        except Exception as e:
            return {"success": False, "error": f"Unexpected error: {e}"}
    
    def format_value(self, value, indent_level=0):
        """Format a value with proper indentation and styling"""
        indent = "  " * indent_level
        
        if isinstance(value, dict):
            if not value:
                return "{}"
            
            result = "{\n"
            for i, (key, val) in enumerate(value.items()):
                comma = "," if i < len(value) - 1 else ""
                result += f"{indent}  <span class='key'>'{key}'</span>: {self.format_value(val, indent_level + 1)}{comma}\n"
            result += f"{indent}}}"
            return result
        
        elif isinstance(value, list):
            if not value:
                return "[]"
            
            result = "[\n"
            for i, item in enumerate(value):
                comma = "," if i < len(value) - 1 else ""
                result += f"{indent}  {self.format_value(item, indent_level + 1)}{comma}\n"
            result += f"{indent}]"
            return result
        
        elif isinstance(value, str):
            # Truncate very long strings
            if len(value) > 200:
                truncated = value[:200] + "..."
                return f"<span class='string'>'{truncated}'</span>"
            return f"<span class='string'>'{value}'</span>"
        
        elif isinstance(value, bool):
            return f"<span class='boolean'>{str(value).lower()}</span>"
        
        elif isinstance(value, (int, float)):
            return f"<span class='number'>{value}</span>"
        
        elif value is None:
            return f"<span class='null'>null</span>"
        
        else:
            return f"<span class='other'>{str(value)}</span>"
    
    def generate_html_report(self, data, filename="parsed_json"):
        """Generate HTML report from parsed JSON data"""
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Count statistics
        def count_items(obj, counts=None):
            if counts is None:
                counts = {"objects": 0, "arrays": 0, "strings": 0, "numbers": 0, "booleans": 0, "nulls": 0}
            
            if isinstance(obj, dict):
                counts["objects"] += 1
                for value in obj.values():
                    count_items(value, counts)
            elif isinstance(obj, list):
                counts["arrays"] += 1
                for item in obj:
                    count_items(item, counts)
            elif isinstance(obj, str):
                counts["strings"] += 1
            elif isinstance(obj, (int, float)):
                counts["numbers"] += 1
            elif isinstance(obj, bool):
                counts["booleans"] += 1
            elif obj is None:
                counts["nulls"] += 1
            
            return counts
        
        stats = count_items(data)
        formatted_json = self.format_value(data)
        
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🦚 JSON Analysis: {filename}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ 
            font-family: 'SF Mono', 'Monaco', 'Cascadia Code', monospace; 
            background: #0d1117; 
            color: #e6edf3; 
            padding: 20px; 
            line-height: 1.6;
        }}
        
        .header {{ 
            background: #161b22; 
            border: 1px solid #30363d; 
            border-radius: 8px; 
            padding: 20px; 
            margin-bottom: 20px; 
        }}
        
        .title {{ 
            color: #ff6b35; 
            font-size: 24px; 
            font-weight: bold; 
            margin-bottom: 10px; 
        }}
        
        .stats {{ 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); 
            gap: 10px; 
            margin-top: 15px; 
        }}
        
        .stat-item {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            border-radius: 6px; 
            padding: 10px; 
            text-align: center; 
        }}
        
        .stat-number {{ 
            color: #00ff88; 
            font-size: 18px; 
            font-weight: bold; 
        }}
        
        .stat-label {{ 
            color: #8b949e; 
            font-size: 12px; 
            text-transform: uppercase; 
        }}
        
        .content {{ 
            background: #161b22; 
            border: 1px solid #30363d; 
            border-radius: 8px; 
            padding: 20px; 
            overflow-x: auto; 
        }}
        
        .json-container {{ 
            background: #0d1117; 
            border: 1px solid #30363d; 
            border-radius: 6px; 
            padding: 15px; 
            font-size: 14px; 
            white-space: pre-wrap; 
            overflow-x: auto; 
        }}
        
        .key {{ color: #79c0ff; font-weight: bold; }}
        .string {{ color: #a5d6ff; }}
        .number {{ color: #79c0ff; }}
        .boolean {{ color: #ff7b72; }}
        .null {{ color: #8b949e; font-style: italic; }}
        .other {{ color: #ffa657; }}
        
        .controls {{ 
            margin-bottom: 15px; 
            display: flex; 
            gap: 10px; 
            flex-wrap: wrap; 
        }}
        
        .btn {{ 
            background: #238636; 
            border: none; 
            color: white; 
            padding: 8px 16px; 
            border-radius: 6px; 
            cursor: pointer; 
            font-size: 12px; 
            font-weight: 600; 
        }}
        
        .btn:hover {{ background: #2ea043; }}
        .btn.secondary {{ background: #21262d; border: 1px solid #30363d; }}
        .btn.secondary:hover {{ background: #30363d; }}
        
        .search-box {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            color: #e6edf3; 
            padding: 8px 12px; 
            border-radius: 6px; 
            font-size: 12px; 
        }}
        
        .highlight {{ background: #ffd33d; color: #0d1117; }}
        
        .footer {{ 
            margin-top: 20px; 
            text-align: center; 
            color: #8b949e; 
            font-size: 12px; 
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="title">🦚 JSON Analysis Report</div>
        <div><strong>File:</strong> {filename}</div>
        <div><strong>Generated:</strong> {timestamp}</div>
        <div><strong>Size:</strong> {len(str(data))} characters</div>
        
        <div class="stats">
            <div class="stat-item">
                <div class="stat-number">{stats['objects']}</div>
                <div class="stat-label">Objects</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{stats['arrays']}</div>
                <div class="stat-label">Arrays</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{stats['strings']}</div>
                <div class="stat-label">Strings</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{stats['numbers']}</div>
                <div class="stat-label">Numbers</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{stats['booleans']}</div>
                <div class="stat-label">Booleans</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{stats['nulls']}</div>
                <div class="stat-label">Nulls</div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="controls">
            <button class="btn" onclick="copyToClipboard()">📋 Copy JSON</button>
            <button class="btn secondary" onclick="toggleCollapse()">🔽 Collapse All</button>
            <button class="btn secondary" onclick="toggleExpand()">🔼 Expand All</button>
            <input type="text" class="search-box" placeholder="Search..." onkeyup="searchJSON(this.value)">
        </div>
        
        <div class="json-container" id="json-content">
{formatted_json}
        </div>
    </div>

    <div class="footer">
        Generated by 🦚 Peacock JSON Parser • {timestamp}
    </div>

    <script>
        function copyToClipboard() {{
            const jsonText = document.getElementById('json-content').textContent;
            navigator.clipboard.writeText(jsonText).then(() => {{
                alert('JSON copied to clipboard!');
            }});
        }}
        
        function toggleCollapse() {{
            // Simple collapse implementation
            const content = document.getElementById('json-content');
            content.style.maxHeight = content.style.maxHeight === '200px' ? 'none' : '200px';
            content.style.overflow = content.style.overflow === 'hidden' ? 'auto' : 'hidden';
        }}
        
        function toggleExpand() {{
            const content = document.getElementById('json-content');
            content.style.maxHeight = 'none';
            content.style.overflow = 'auto';
        }}
        
        function searchJSON(query) {{
            const content = document.getElementById('json-content');
            let html = content.innerHTML;
            
            // Remove previous highlights
            html = html.replace(/<span class="highlight">(.*?)<\/span>/g, '$1');
            
            if (query.trim()) {{
                const regex = new RegExp(`(${query.replace(/[.*+?^${{}}()|[\\]\\\\]/g, '\\\\$&')})`, 'gi');
                html = html.replace(regex, '<span class="highlight">$1</span>');
            }}
            
            content.innerHTML = html;
        }}
        
        // Raw JSON data for reference
        const rawData = {json.dumps(data, indent=2)};
        console.log('Raw JSON data:', rawData);
    </script>
</body>
</html>"""
        
        output_file = f"{self.output_dir}/{filename}_{timestamp}.html"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return output_file
    
    def generate_text_report(self, data, filename="parsed_json"):
        """Generate plain text report from parsed JSON data"""
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        
        def format_text(obj, indent=0):
            spaces = "  " * indent
            if isinstance(obj, dict):
                result = "{\n"
                for key, value in obj.items():
                    result += f"{spaces}  {key}: {format_text(value, indent + 1)}\n"
                result += f"{spaces}}}"
                return result
            elif isinstance(obj, list):
                result = "[\n"
                for item in obj:
                    result += f"{spaces}  {format_text(item, indent + 1)}\n"
                result += f"{spaces}]"
                return result
            else:
                return str(obj)
        
        text_content = f"""
🦚 PEACOCK JSON ANALYSIS REPORT
{'=' * 50}

File: {filename}
Generated: {timestamp}
Size: {len(str(data))} characters

FORMATTED JSON:
{'-' * 30}
{format_text(data)}

RAW JSON (Pretty):
{'-' * 30}
{json.dumps(data, indent=2)}
"""
        
        output_file = f"{self.output_dir}/{filename}_{timestamp}.txt"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(text_content)
        
        return output_file

def main():
    parser = JSONParser()
    
    print("🦚 PEACOCK JSON PARSER")
    print("=" * 50)
    
    # Get input method
    print("\nChoose input method:")
    print("1. Parse JSON file")
    print("2. Parse JSON string (paste directly)")
    print("3. Parse from clipboard")
    
    choice = input("\nEnter choice (1-3): ").strip()
    
    if choice == "1":
        # File input
        file_path = input("Enter JSON file path: ").strip()
        result = parser.parse_json_file(file_path)
        filename = Path(file_path).stem
        
    elif choice == "2":
        # String input
        print("\nPaste your JSON (press Ctrl+D when done):")
        json_string = sys.stdin.read()
        result = parser.parse_json_string(json_string)
        filename = "pasted_json"
        
    elif choice == "3":
        # Clipboard input (requires pyperclip)
        try:
            import pyperclip
            json_string = pyperclip.paste()
            result = parser.parse_json_string(json_string)
            filename = "clipboard_json"
        except ImportError:
            print("❌ pyperclip not installed. Install with: pip install pyperclip")
            return
        except Exception as e:
            print(f"❌ Clipboard error: {e}")
            return
    
    else:
        print("❌ Invalid choice")
        return
    
    if not result["success"]:
        print(f"❌ Error: {result['error']}")
        return
    
    data = result["data"]
    
    # Generate reports
    print("\n🔄 Generating reports...")
    
    html_file = parser.generate_html_report(data, filename)
    text_file = parser.generate_text_report(data, filename)
    
    print(f"\n✅ Reports generated:")
    print(f"   📄 HTML: {html_file}")
    print(f"   📝 Text: {text_file}")
    
    # Open HTML file
    try:
        import webbrowser
        webbrowser.open(f"file://{os.path.abspath(html_file)}")
        print(f"\n🌐 Opening HTML report in browser...")
    except Exception as e:
        print(f"\n⚠️  Could not open browser: {e}")
    
    print(f"\n🎉 JSON parsing complete!")

if __name__ == "__main__":
    main()