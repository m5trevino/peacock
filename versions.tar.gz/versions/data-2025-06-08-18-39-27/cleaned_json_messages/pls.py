#!/usr/bin/env python3
"""
JSON Project Data Cleaner - Clean up JSON project files to human-readable format
Specifically designed for project data with descriptions, docs, and nested content
"""

import json
import sys
import re
from pathlib import Path
import datetime

class JSONProjectCleaner:
    def __init__(self):
        self.output_dir = "cleaned_project_json"
        Path(self.output_dir).mkdir(exist_ok=True)
    
    def clean_text_content(self, text):
        """Clean up escaped text content to make it human readable"""
        if not isinstance(text, str):
            return text
        
        # Unescape common escape sequences
        text = text.replace('\\n', '\n')
        text = text.replace('\\t', '\t')
        text = text.replace('\\r', '\r')
        text = text.replace('\\"', '"')
        text = text.replace("\\'", "'")
        text = text.replace('\\\\', '\\')
        
        # Handle Unicode escape sequences
        text = re.sub(r'\\u([0-9a-fA-F]{4})', lambda m: chr(int(m.group(1), 16)), text)
        
        # Clean up excessive whitespace but preserve intentional formatting
        text = re.sub(r'\n\s*\n\s*\n+', '\n\n', text)
        text = re.sub(r'[ \t]+', ' ', text)
        
        return text.strip()
    
    def process_json_recursively(self, obj):
        """Recursively process JSON object to clean text content"""
        if isinstance(obj, dict):
            cleaned = {}
            for key, value in obj.items():
                if key in ["description", "content", "text", "prompt_template"] and isinstance(value, str):
                    # Special handling for text content fields
                    cleaned[key] = self.clean_text_content(value)
                else:
                    cleaned[key] = self.process_json_recursively(value)
            return cleaned
        
        elif isinstance(obj, list):
            return [self.process_json_recursively(item) for item in obj]
        
        elif isinstance(obj, str):
            # Clean any string that looks like it has escape sequences
            if '\\n' in obj or '\\t' in obj or '\\u' in obj:
                return self.clean_text_content(obj)
            return obj
        
        else:
            return obj
    
    def extract_project_info(self, data):
        """Extract key information from project data"""
        info = {
            "total_projects": 0,
            "project_names": [],
            "creators": set(),
            "total_docs": 0,
            "doc_types": set(),
            "has_descriptions": 0,
            "private_projects": 0,
            "starter_projects": 0
        }
        
        def analyze_recursive(obj):
            if isinstance(obj, dict):
                # Count projects
                if "uuid" in obj and "name" in obj and "created_at" in obj:
                    info["total_projects"] += 1
                    info["project_names"].append(obj.get("name", "Unnamed"))
                    
                    if obj.get("description"):
                        info["has_descriptions"] += 1
                    
                    if obj.get("is_private"):
                        info["private_projects"] += 1
                    
                    if obj.get("is_starter_project"):
                        info["starter_projects"] += 1
                
                # Track creators
                if "creator" in obj and isinstance(obj["creator"], dict):
                    creator_name = obj["creator"].get("full_name", "Unknown")
                    info["creators"].add(creator_name)
                
                # Count docs
                if "docs" in obj and isinstance(obj["docs"], list):
                    info["total_docs"] += len(obj["docs"])
                    for doc in obj["docs"]:
                        if isinstance(doc, dict) and "filename" in doc:
                            ext = Path(doc["filename"]).suffix
                            if ext:
                                info["doc_types"].add(ext)
                
                # Recurse into nested objects
                for value in obj.values():
                    analyze_recursive(value)
            
            elif isinstance(obj, list):
                for item in obj:
                    analyze_recursive(item)
        
        analyze_recursive(data)
        
        # Convert sets to lists for JSON serialization
        info["creators"] = list(info["creators"])
        info["doc_types"] = list(info["doc_types"])
        
        return info
    
    def generate_readable_html(self, original_data, cleaned_data, filename="project_data"):
        """Generate human-readable HTML report"""
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Extract project information
        project_info = self.extract_project_info(cleaned_data)
        
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🦚 Cleaned Project Data: {filename}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ 
            font-family: 'SF Mono', 'Monaco', 'Cascadia Code', monospace; 
            background: #0d1117; 
            color: #e6edf3; 
            padding: 20px; 
            line-height: 1.6;
        }}
        
        .header {{ 
            background: #161b22; 
            border: 1px solid #30363d; 
            border-radius: 8px; 
            padding: 20px; 
            margin-bottom: 20px; 
        }}
        
        .title {{ 
            color: #ff6b35; 
            font-size: 24px; 
            font-weight: bold; 
            margin-bottom: 10px; 
        }}
        
        .stats {{ 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); 
            gap: 10px; 
            margin-top: 15px; 
        }}
        
        .stat-item {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            border-radius: 6px; 
            padding: 10px; 
            text-align: center; 
        }}
        
        .stat-number {{ 
            color: #00ff88; 
            font-size: 18px; 
            font-weight: bold; 
        }}
        
        .stat-label {{ 
            color: #8b949e; 
            font-size: 12px; 
            text-transform: uppercase; 
        }}
        
        .section {{ 
            background: #161b22; 
            border: 1px solid #30363d; 
            border-radius: 8px; 
            padding: 20px; 
            margin-bottom: 20px; 
        }}
        
        .section-title {{ 
            color: #00ff88; 
            font-size: 18px; 
            font-weight: bold; 
            margin-bottom: 15px; 
            border-bottom: 1px solid #30363d; 
            padding-bottom: 5px; 
        }}
        
        .project-item {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            border-radius: 6px; 
            padding: 15px; 
            margin: 10px 0; 
        }}
        
        .project-header {{ 
            color: #79c0ff; 
            font-weight: bold; 
            margin-bottom: 8px; 
            border-bottom: 1px solid #30363d; 
            padding-bottom: 5px; 
        }}
        
        .project-description {{ 
            background: #0d1117; 
            border: 1px solid #30363d; 
            border-radius: 4px; 
            padding: 10px; 
            margin: 8px 0; 
            white-space: pre-wrap; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            line-height: 1.5; 
        }}
        
        .doc-content {{ 
            background: #0d1117; 
            border: 1px solid #30363d; 
            border-radius: 4px; 
            padding: 10px; 
            margin: 8px 0; 
            white-space: pre-wrap; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            max-height: 400px; 
            overflow-y: auto; 
        }}
        
        .json-container {{ 
            background: #0d1117; 
            border: 1px solid #30363d; 
            border-radius: 6px; 
            padding: 15px; 
            white-space: pre-wrap; 
            overflow-x: auto; 
            max-height: 600px; 
            overflow-y: auto; 
            font-size: 13px; 
        }}
        
        .controls {{ 
            margin-bottom: 15px; 
            display: flex; 
            gap: 10px; 
            flex-wrap: wrap; 
        }}
        
        .btn {{ 
            background: #238636; 
            border: none; 
            color: white; 
            padding: 8px 16px; 
            border-radius: 6px; 
            cursor: pointer; 
            font-size: 12px; 
            font-weight: 600; 
        }}
        
        .btn:hover {{ background: #2ea043; }}
        .btn.secondary {{ background: #21262d; border: 1px solid #30363d; }}
        .btn.secondary:hover {{ background: #30363d; }}
        
        .search-box {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            color: #e6edf3; 
            padding: 8px 12px; 
            border-radius: 6px; 
            font-size: 12px; 
        }}
        
        .info-list {{ 
            list-style: none; 
        }}
        
        .info-list li {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            border-radius: 4px; 
            padding: 8px 12px; 
            margin: 5px 0; 
        }}
        
        .badge {{ 
            display: inline-block; 
            background: #ff6b35; 
            color: #0d1117; 
            padding: 2px 6px; 
            border-radius: 3px; 
            font-size: 10px; 
            font-weight: bold; 
            margin-left: 8px; 
        }}
        
        .badge.private {{ background: #da3633; }}
        .badge.starter {{ background: #00ff88; }}
    </style>
</head>
<body>
    <div class="header">
        <div class="title">🦚 Cleaned Project Data</div>
        <div><strong>File:</strong> {filename}</div>
        <div><strong>Generated:</strong> {timestamp}</div>
        <div><strong>Original Size:</strong> {len(str(original_data))} characters</div>
        <div><strong>Cleaned Size:</strong> {len(str(cleaned_data))} characters</div>
        
        <div class="stats">
            <div class="stat-item">
                <div class="stat-number">{project_info['total_projects']}</div>
                <div class="stat-label">Projects</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{project_info['total_docs']}</div>
                <div class="stat-label">Documents</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{len(project_info['creators'])}</div>
                <div class="stat-label">Creators</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{project_info['private_projects']}</div>
                <div class="stat-label">Private</div>
            </div>
        </div>
    </div>"""
        
        # Add project names overview
        if project_info['project_names']:
            html_content += f"""
    <div class="section">
        <div class="section-title">📁 Projects ({len(project_info['project_names'])})</div>
        <ul class="info-list">"""
            for name in project_info['project_names']:
                html_content += f"<li>{name}</li>"
            html_content += "</ul></div>"
        
        # Add creators overview
        if project_info['creators']:
            html_content += f"""
    <div class="section">
        <div class="section-title">👥 Creators ({len(project_info['creators'])})</div>
        <ul class="info-list">"""
            for creator in project_info['creators']:
                html_content += f"<li>{creator}</li>"
            html_content += "</ul></div>"
        
        # Add readable projects section
        html_content += f"""
    <div class="section">
        <div class="section-title">📖 Readable Project Data</div>
        <div class="controls">
            <button class="btn" onclick="showProjects()">📁 Show Projects</button>
            <button class="btn secondary" onclick="showJSON()">📋 Show JSON</button>
            <input type="text" class="search-box" placeholder="Search projects..." onkeyup="searchContent(this.value)">
        </div>
        
        <div id="projects-view">"""
        
        # Extract and display readable projects
        def extract_projects(obj, projects=None):
            if projects is None:
                projects = []
            
            if isinstance(obj, list):
                for item in obj:
                    if isinstance(item, dict) and "name" in item and "uuid" in item:
                        projects.append(item)
                    else:
                        extract_projects(item, projects)
            elif isinstance(obj, dict):
                if "name" in obj and "uuid" in obj:
                    projects.append(obj)
                else:
                    for value in obj.values():
                        extract_projects(value, projects)
            
            return projects
        
        projects = extract_projects(cleaned_data)
        
        for i, project in enumerate(projects):
            name = project.get('name', 'Unnamed Project')
            description = project.get('description', 'No description')
            creator = project.get('creator', {}).get('full_name', 'Unknown')
            created_at = project.get('created_at', '')
            is_private = project.get('is_private', False)
            is_starter = project.get('is_starter_project', False)
            docs = project.get('docs', [])
            
            badges = ""
            if is_private:
                badges += '<span class="badge private">PRIVATE</span>'
            if is_starter:
                badges += '<span class="badge starter">STARTER</span>'
            
            html_content += f"""
            <div class="project-item">
                <div class="project-header">
                    {name} {badges}
                    <br><small>By {creator} • {created_at[:10] if created_at else 'No date'} • {len(docs)} docs</small>
                </div>
                <div class="project-description">{description}</div>"""
            
            # Add documents
            if docs:
                html_content += f"""
                <div style="margin-top: 15px;">
                    <strong>📄 Documents ({len(docs)}):</strong>"""
                
                for doc in docs:
                    doc_name = doc.get('filename', 'Unnamed Document')
                    doc_content = doc.get('content', 'No content')
                    
                    html_content += f"""
                    <div style="margin: 10px 0;">
                        <strong>{doc_name}</strong>
                        <div class="doc-content">{doc_content}</div>
                    </div>"""
                
                html_content += "</div>"
            
            html_content += "</div>"
        
        html_content += """
        </div>
        
        <div id="json-view" style="display: none;">
            <div class="json-container">"""
        
        html_content += json.dumps(cleaned_data, indent=2, ensure_ascii=False)
        
        html_content += """</div>
        </div>
    </div>

    <script>
        function showProjects() {
            document.getElementById('projects-view').style.display = 'block';
            document.getElementById('json-view').style.display = 'none';
        }
        
        function showJSON() {
            document.getElementById('projects-view').style.display = 'none';
            document.getElementById('json-view').style.display = 'block';
        }
        
        function searchContent(query) {
            const projects = document.querySelectorAll('.project-item');
            projects.forEach(project => {
                const text = project.textContent.toLowerCase();
                
                if (query.trim() === '' || text.includes(query.toLowerCase())) {
                    project.style.display = 'block';
                } else {
                    project.style.display = 'none';
                }
            });
        }
        
        // Raw data for console access
        const cleanedData = """ + json.dumps(cleaned_data) + """;
        console.log('Cleaned project data available as cleanedData variable');
    </script>
</body>
</html>"""
        
        # Save HTML file
        html_file = f"{self.output_dir}/{filename}_readable_{timestamp}.html"
        with open(html_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return html_file
    
    def generate_clean_text(self, cleaned_data, filename="project_data"):
        """Generate clean text version"""
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        
        def extract_text_content(obj, texts=None):
            if texts is None:
                texts = []
            
            if isinstance(obj, list):
                for item in obj:
                    if isinstance(item, dict) and "name" in item:
                        name = item.get("name", "Unnamed")
                        description = item.get("description", "No description")
                        creator = item.get("creator", {}).get("full_name", "Unknown")
                        
                        texts.append(f"PROJECT: {name}")
                        texts.append(f"Creator: {creator}")
                        texts.append(f"Description: {description}")
                        
                        docs = item.get("docs", [])
                        if docs:
                            texts.append(f"Documents ({len(docs)}):")
                            for doc in docs:
                                doc_name = doc.get("filename", "Unnamed")
                                doc_content = doc.get("content", "No content")
                                texts.append(f"  - {doc_name}")
                                texts.append(f"    {doc_content[:200]}{'...' if len(doc_content) > 200 else ''}")
                        
                        texts.append("=" * 60)
                    else:
                        extract_text_content(item, texts)
            elif isinstance(obj, dict):
                for value in obj.values():
                    extract_text_content(value, texts)
            
            return texts
        
        text_content = extract_text_content(cleaned_data)
        
        text_file = f"{self.output_dir}/{filename}_readable_{timestamp}.txt"
        with open(text_file, 'w', encoding='utf-8') as f:
            f.write("🦚 PEACOCK PROJECT DATA - READABLE TEXT\n")
            f.write("=" * 60 + "\n\n")
            f.write("\n".join(text_content))
        
        return text_file
    
    def process_json_file(self, file_path):
        """Process JSON file and generate cleaned versions"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                original_data = json.load(f)
        except Exception as e:
            print(f"❌ Error reading JSON file: {e}")
            return None
        
        print(f"📄 Processing: {file_path}")
        print(f"📏 Original size: {len(str(original_data))} characters")
        
        # Clean the JSON data
        cleaned_data = self.process_json_recursively(original_data)
        
        filename = Path(file_path).stem
        
        # Generate outputs
        html_file = self.generate_readable_html(original_data, cleaned_data, filename)
        text_file = self.generate_clean_text(cleaned_data, filename)
        
        # Save cleaned JSON
        json_file = f"{self.output_dir}/{filename}_cleaned_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(cleaned_data, f, indent=2, ensure_ascii=False)
        
        return {
            "html_file": html_file,
            "text_file": text_file,
            "json_file": json_file,
            "original_size": len(str(original_data)),
            "cleaned_size": len(str(cleaned_data))
        }

def main():
    cleaner = JSONProjectCleaner()
    
    print("🦚 PEACOCK PROJECT JSON CLEANER")
    print("=" * 50)
    
    if len(sys.argv) != 2:
        print("Usage: python3 clean_project_json.py <json_file>")
        print("Example: python3 clean_project_json.py projects.json")
        sys.exit(1)
    
    file_path = sys.argv[1]
    
    if not Path(file_path).exists():
        print(f"❌ File not found: {file_path}")
        sys.exit(1)
    
    # Process the file
    result = cleaner.process_json_file(file_path)
    
    if result:
        print(f"\n✅ CLEANING COMPLETE!")
        print(f"   📄 HTML Report: {result['html_file']}")
        print(f"   📝 Text Version: {result['text_file']}")
        print(f"   📋 Cleaned JSON: {result['json_file']}")
        print(f"   📏 Size reduction: {result['original_size']} → {result['cleaned_size']} chars")
        
        # Try to open HTML file
        try:
            import webbrowser
            import os
            webbrowser.open(f"file://{os.path.abspath(result['html_file'])}")
            print(f"\n🌐 Opening HTML report in browser...")
        except Exception as e:
            print(f"\n⚠️  Could not open browser: {e}")
        
        print(f"\n🎉 Project JSON cleaning complete!")
    else:
        print(f"\n❌ Failed to process file")

if __name__ == "__main__":
    main()