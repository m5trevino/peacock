#!/usr/bin/env python3
"""
Quick JSON Parser - Simple command line JSON formatter
Usage: python3 quick_json_parse.py <json_file>
"""

import json
import sys
from pathlib import Path

def parse_and_display(json_file):
    """Parse JSON file and display in readable format"""
    try:
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        print("🦚" + "="*60 + "🦚")
        print(f"    JSON ANALYSIS: {Path(json_file).name}")
        print("🦚" + "="*60 + "🦚")
        print()
        
        # Statistics
        def count_types(obj):
            counts = {"objects": 0, "arrays": 0, "strings": 0, "numbers": 0, "booleans": 0, "nulls": 0}
            
            def count_recursive(item):
                if isinstance(item, dict):
                    counts["objects"] += 1
                    for value in item.values():
                        count_recursive(value)
                elif isinstance(item, list):
                    counts["arrays"] += 1
                    for value in item:
                        count_recursive(value)
                elif isinstance(item, str):
                    counts["strings"] += 1
                elif isinstance(item, (int, float)):
                    counts["numbers"] += 1
                elif isinstance(item, bool):
                    counts["booleans"] += 1
                elif item is None:
                    counts["nulls"] += 1
            
            count_recursive(obj)
            return counts
        
        stats = count_types(data)
        
        print("📊 STATISTICS:")
        print(f"   Objects: {stats['objects']}")
        print(f"   Arrays: {stats['arrays']}")
        print(f"   Strings: {stats['strings']}")
        print(f"   Numbers: {stats['numbers']}")
        print(f"   Booleans: {stats['booleans']}")
        print(f"   Nulls: {stats['nulls']}")
        print()
        
        print("📋 FORMATTED JSON:")
        print("-" * 60)
        print(json.dumps(data, indent=2, ensure_ascii=False))
        print("-" * 60)
        
        # Show structure overview
        print("\n🏗️  STRUCTURE OVERVIEW:")
        def show_structure(obj, prefix="", max_depth=3, current_depth=0):
            if current_depth >= max_depth:
                return
            
            if isinstance(obj, dict):
                for key, value in obj.items():
                    if isinstance(value, dict):
                        print(f"{prefix}📁 {key}: object ({len(value)} keys)")
                        show_structure(value, prefix + "  ", max_depth, current_depth + 1)
                    elif isinstance(value, list):
                        print(f"{prefix}📋 {key}: array ({len(value)} items)")
                        if value and current_depth < max_depth - 1:
                            show_structure(value[0], prefix + "  ", max_depth, current_depth + 1)
                    else:
                        value_preview = str(value)[:50] + "..." if len(str(value)) > 50 else str(value)
                        print(f"{prefix}📄 {key}: {type(value).__name__} = {value_preview}")
            
            elif isinstance(obj, list) and obj:
                print(f"{prefix}📋 Array item example:")
                show_structure(obj[0], prefix + "  ", max_depth, current_depth + 1)
        
        show_structure(data)
        
        print(f"\n✅ Total size: {len(str(data))} characters")
        
    except json.JSONDecodeError as e:
        print(f"❌ JSON decode error: {e}")
    except FileNotFoundError:
        print(f"❌ File not found: {json_file}")
    except Exception as e:
        print(f"❌ Error: {e}")

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 quick_json_parse.py <json_file>")
        print("Example: python3 quick_json_parse.py data.json")
        sys.exit(1)
    
    json_file = sys.argv[1]
    parse_and_display(json_file)

if __name__ == "__main__":
    main()