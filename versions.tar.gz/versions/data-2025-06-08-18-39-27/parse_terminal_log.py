#!/usr/bin/env python3
"""
Terminal Log Parser - Clean up mixed terminal output and JSON data
Specifically designed for Peacock pipeline logs and debugging output
"""

import re
import json
import sys
from pathlib import Path
import datetime

class TerminalLogParser:
    def __init__(self):
        self.output_dir = "cleaned_logs"
        Path(self.output_dir).mkdir(exist_ok=True)
    
    def clean_terminal_artifacts(self, content):
        """Remove terminal control characters and artifacts"""
        # Remove ANSI escape sequences
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        content = ansi_escape.sub('', content)
        
        # Remove terminal prompt artifacts
        content = re.sub(r'\(peacock\)\s+[✘✓]?\s*flintx[💀@].*?└─⚡\s*', '', content)
        content = re.sub(r'dquote>\s*', '', content)
        content = re.sub(r'--\s*$', '', content, flags=re.MULTILINE)
        
        # Clean up extra whitespace
        content = re.sub(r'\n\s*\n\s*\n', '\n\n', content)
        
        return content.strip()
    
    def extract_json_blocks(self, content):
        """Extract JSON blocks from mixed content"""
        json_blocks = []
        
        # Pattern for JSON objects
        json_pattern = r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}'
        matches = re.findall(json_pattern, content, re.DOTALL)
        
        for match in matches:
            try:
                # Try to parse as JSON
                parsed = json.loads(match)
                json_blocks.append({
                    "raw": match,
                    "parsed": parsed,
                    "valid": True
                })
            except json.JSONDecodeError:
                # Keep invalid JSON for reference
                json_blocks.append({
                    "raw": match,
                    "parsed": None,
                    "valid": False
                })
        
        return json_blocks
    
    def extract_commands_and_output(self, content):
        """Extract command executions and their outputs"""
        commands = []
        
        # Pattern for commands and their outputs
        lines = content.split('\n')
        current_command = None
        current_output = []
        
        for line in lines:
            # Check if line looks like a command
            if any(indicator in line for indicator in ['curl', 'echo', 'find', 'grep', 'python3']):
                if current_command:
                    commands.append({
                        "command": current_command,
                        "output": '\n'.join(current_output)
                    })
                current_command = line.strip()
                current_output = []
            elif current_command and line.strip():
                current_output.append(line)
        
        # Add the last command
        if current_command:
            commands.append({
                "command": current_command,
                "output": '\n'.join(current_output)
            })
        
        return commands
    
    def extract_urls_and_endpoints(self, content):
        """Extract URLs and API endpoints"""
        urls = []
        
        # Pattern for URLs
        url_pattern = r'https?://[^\s\'"<>]+'
        urls.extend(re.findall(url_pattern, content))
        
        # Pattern for localhost endpoints
        localhost_pattern = r'localhost:\d+[^\s\'"<>]*'
        urls.extend(['http://' + match for match in re.findall(localhost_pattern, content)])
        
        # Pattern for 127.0.0.1 endpoints
        ip_pattern = r'127\.0\.0\.1:\d+[^\s\'"<>]*'
        urls.extend(['http://' + match for match in re.findall(ip_pattern, content)])
        
        return list(set(urls))  # Remove duplicates
    
    def extract_file_paths(self, content):
        """Extract file paths from the content"""
        file_paths = []
        
        # Pattern for file paths
        path_patterns = [
            r'/home/[^\s\'"<>]+',
            r'[^\s\'"<>]*\.html',
            r'[^\s\'"<>]*\.json',
            r'[^\s\'"<>]*\.txt',
            r'[^\s\'"<>]*\.py'
        ]
        
        for pattern in path_patterns:
            file_paths.extend(re.findall(pattern, content))
        
        return list(set(file_paths))  # Remove duplicates
    
    def generate_cleaned_report(self, content, filename="terminal_log"):
        """Generate a cleaned, human-readable report"""
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Clean the content
        cleaned_content = self.clean_terminal_artifacts(content)
        
        # Extract different types of data
        json_blocks = self.extract_json_blocks(cleaned_content)
        commands = self.extract_commands_and_output(cleaned_content)
        urls = self.extract_urls_and_endpoints(cleaned_content)
        file_paths = self.extract_file_paths(cleaned_content)
        
        # Generate HTML report
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🦚 Terminal Log Analysis: {filename}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ 
            font-family: 'SF Mono', 'Monaco', 'Cascadia Code', monospace; 
            background: #0d1117; 
            color: #e6edf3; 
            padding: 20px; 
            line-height: 1.6;
        }}
        
        .header {{ 
            background: #161b22; 
            border: 1px solid #30363d; 
            border-radius: 8px; 
            padding: 20px; 
            margin-bottom: 20px; 
        }}
        
        .title {{ 
            color: #ff6b35; 
            font-size: 24px; 
            font-weight: bold; 
            margin-bottom: 10px; 
        }}
        
        .section {{ 
            background: #161b22; 
            border: 1px solid #30363d; 
            border-radius: 8px; 
            padding: 20px; 
            margin-bottom: 20px; 
        }}
        
        .section-title {{ 
            color: #00ff88; 
            font-size: 18px; 
            font-weight: bold; 
            margin-bottom: 15px; 
            border-bottom: 1px solid #30363d; 
            padding-bottom: 5px; 
        }}
        
        .item {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            border-radius: 6px; 
            padding: 15px; 
            margin-bottom: 10px; 
        }}
        
        .command {{ 
            color: #79c0ff; 
            font-weight: bold; 
            margin-bottom: 8px; 
        }}
        
        .output {{ 
            color: #a5d6ff; 
            background: #0d1117; 
            padding: 10px; 
            border-radius: 4px; 
            white-space: pre-wrap; 
            overflow-x: auto; 
        }}
        
        .json-block {{ 
            background: #0d1117; 
            border: 1px solid #30363d; 
            border-radius: 4px; 
            padding: 10px; 
            margin: 10px 0; 
            overflow-x: auto; 
        }}
        
        .valid-json {{ border-left: 3px solid #00ff88; }}
        .invalid-json {{ border-left: 3px solid #ff6b6b; }}
        
        .url-list, .path-list {{ 
            list-style: none; 
        }}
        
        .url-list li, .path-list li {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            border-radius: 4px; 
            padding: 8px 12px; 
            margin: 5px 0; 
            word-break: break-all; 
        }}
        
        .url-list li {{ color: #79c0ff; }}
        .path-list li {{ color: #ffa657; }}
        
        .stats {{ 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); 
            gap: 10px; 
            margin-bottom: 15px; 
        }}
        
        .stat-item {{ 
            background: #21262d; 
            border: 1px solid #30363d; 
            border-radius: 6px; 
            padding: 10px; 
            text-align: center; 
        }}
        
        .stat-number {{ 
            color: #00ff88; 
            font-size: 18px; 
            font-weight: bold; 
        }}
        
        .stat-label {{ 
            color: #8b949e; 
            font-size: 12px; 
            text-transform: uppercase; 
        }}
        
        .raw-content {{ 
            background: #0d1117; 
            border: 1px solid #30363d; 
            border-radius: 4px; 
            padding: 15px; 
            white-space: pre-wrap; 
            overflow-x: auto; 
            max-height: 400px; 
            overflow-y: auto; 
        }}
        
        .toggle-btn {{ 
            background: #238636; 
            border: none; 
            color: white; 
            padding: 8px 16px; 
            border-radius: 6px; 
            cursor: pointer; 
            font-size: 12px; 
            margin-bottom: 10px; 
        }}
        
        .toggle-btn:hover {{ background: #2ea043; }}
    </style>
</head>
<body>
    <div class="header">
        <div class="title">🦚 Terminal Log Analysis</div>
        <div><strong>File:</strong> {filename}</div>
        <div><strong>Generated:</strong> {timestamp}</div>
        <div><strong>Original Size:</strong> {len(content)} characters</div>
        <div><strong>Cleaned Size:</strong> {len(cleaned_content)} characters</div>
        
        <div class="stats">
            <div class="stat-item">
                <div class="stat-number">{len(json_blocks)}</div>
                <div class="stat-label">JSON Blocks</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{len(commands)}</div>
                <div class="stat-label">Commands</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{len(urls)}</div>
                <div class="stat-label">URLs</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{len(file_paths)}</div>
                <div class="stat-label">File Paths</div>
            </div>
        </div>
    </div>"""
        
        # Add JSON blocks section
        if json_blocks:
            html_content += f"""
    <div class="section">
        <div class="section-title">📋 JSON Blocks Found ({len(json_blocks)})</div>"""
            
            for i, block in enumerate(json_blocks):
                status = "valid-json" if block["valid"] else "invalid-json"
                status_text = "✅ Valid JSON" if block["valid"] else "❌ Invalid JSON"
                
                html_content += f"""
        <div class="item">
            <div class="command">Block {i+1}: {status_text}</div>
            <div class="json-block {status}">"""
                
                if block["valid"]:
                    html_content += json.dumps(block["parsed"], indent=2)
                else:
                    html_content += block["raw"]
                
                html_content += """</div>
        </div>"""
            
            html_content += "</div>"
        
        # Add commands section
        if commands:
            html_content += f"""
    <div class="section">
        <div class="section-title">💻 Commands Executed ({len(commands)})</div>"""
            
            for i, cmd in enumerate(commands):
                html_content += f"""
        <div class="item">
            <div class="command">{cmd['command']}</div>
            <div class="output">{cmd['output']}</div>
        </div>"""
            
            html_content += "</div>"
        
        # Add URLs section
        if urls:
            html_content += f"""
    <div class="section">
        <div class="section-title">🌐 URLs & Endpoints ({len(urls)})</div>
        <ul class="url-list">"""
            
            for url in urls:
                html_content += f"<li>{url}</li>"
            
            html_content += "</ul></div>"
        
        # Add file paths section
        if file_paths:
            html_content += f"""
    <div class="section">
        <div class="section-title">📁 File Paths ({len(file_paths)})</div>
        <ul class="path-list">"""
            
            for path in file_paths:
                html_content += f"<li>{path}</li>"
            
            html_content += "</ul></div>"
        
        # Add raw cleaned content section
        html_content += f"""
    <div class="section">
        <div class="section-title">📄 Cleaned Raw Content</div>
        <button class="toggle-btn" onclick="toggleRawContent()">Toggle Raw Content</button>
        <div class="raw-content" id="raw-content" style="display: none;">
{cleaned_content}
        </div>
    </div>

    <script>
        function toggleRawContent() {{
            const content = document.getElementById('raw-content');
            content.style.display = content.style.display === 'none' ? 'block' : 'none';
        }}
    </script>
</body>
</html>"""
        
        # Save HTML report
        html_file = f"{self.output_dir}/{filename}_cleaned_{timestamp}.html"
        with open(html_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        # Save cleaned text
        text_file = f"{self.output_dir}/{filename}_cleaned_{timestamp}.txt"
        with open(text_file, 'w', encoding='utf-8') as f:
            f.write(f"""🦚 PEACOCK TERMINAL LOG ANALYSIS
{'=' * 60}

File: {filename}
Generated: {timestamp}
Original Size: {len(content)} characters
Cleaned Size: {len(cleaned_content)} characters

STATISTICS:
- JSON Blocks: {len(json_blocks)}
- Commands: {len(commands)}
- URLs: {len(urls)}
- File Paths: {len(file_paths)}

CLEANED CONTENT:
{'-' * 60}
{cleaned_content}

JSON BLOCKS:
{'-' * 60}
""")
            
            for i, block in enumerate(json_blocks):
                f.write(f"\nBlock {i+1} ({'Valid' if block['valid'] else 'Invalid'}):\n")
                if block["valid"]:
                    f.write(json.dumps(block["parsed"], indent=2))
                else:
                    f.write(block["raw"])
                f.write("\n" + "-" * 40)
        
        return html_file, text_file

def main():
    parser = TerminalLogParser()
    
    print("🦚 PEACOCK TERMINAL LOG PARSER")
    print("=" * 50)
    
    if len(sys.argv) > 1:
        # File provided as argument
        file_path = sys.argv[1]
        filename = Path(file_path).stem
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            print(f"❌ Error reading file: {e}")
            return
    else:
        # Read from stdin or prompt for file
        print("Enter file path or paste content (Ctrl+D when done):")
        try:
            content = sys.stdin.read()
            filename = "pasted_content"
        except KeyboardInterrupt:
            print("\n❌ Cancelled")
            return
    
    if not content.strip():
        print("❌ No content provided")
        return
    
    print(f"\n🔄 Processing {len(content)} characters...")
    
    # Generate reports
    html_file, text_file = parser.generate_cleaned_report(content, filename)
    
    print(f"\n✅ Reports generated:")
    print(f"   📄 HTML: {html_file}")
    print(f"   📝 Text: {text_file}")
    
    # Try to open HTML file
    try:
        import webbrowser
        import os
        webbrowser.open(f"file://{os.path.abspath(html_file)}")
        print(f"\n🌐 Opening HTML report in browser...")
    except Exception as e:
        print(f"\n⚠️  Could not open browser: {e}")
    
    print(f"\n🎉 Terminal log parsing complete!")

if __name__ == "__main__":
    main()