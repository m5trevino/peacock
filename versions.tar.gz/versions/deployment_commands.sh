# Peacock Multi-Model Optimization Deployment Commands
# Execute these commands to upgrade your Peacock setup

# 1. Backup your current setup (safety first, my boy)
cp /home/flintx/peacock/peamcp.py /home/flintx/peacock/peamcp.py.backup
cp /home/flintx/peacock/moddash.py /home/flintx/peacock/moddash.py.backup  
cp /home/flintx/peacock/xedit.py /home/flintx/peacock/xedit.py.backup

# 2. Deploy the optimized peamcp.py (Multi-Model Strategy)
cat << 'EOF' > /home/flintx/peacock/peamcp.py
# [Insert the enhanced_peamcp content from the artifact above]
EOF

# 3. Deploy the optimized moddash.py (Dashboard with Metrics)
cat << 'EOF' > /home/flintx/peacock/moddash.py
# [Insert the optimized_moddash content from the artifact above]  
EOF

# 4. Deploy the optimized xedit.py (Multi-Model Code Analysis)
cat << 'EOF' > /home/flintx/peacock/xedit.py
# [Insert the optimized_xedit content from the artifact above]
EOF

# 5. Install required Python dependencies
pip install groq regex

# 6. Test the optimized server
cd /home/flintx/peacock
python peamcp.py --log

# 7. Generate optimized dashboard
python moddash.py

# 8. Test multi-model strategy
curl -X POST http://127.0.0.1:8000/process \
  -H "Content-Type: application/json" \
  -d '{
    "command": "peacock_full",
    "text": "Build a simple calculator app"
  }'

# 9. Check server health with new optimization info
curl http://127.0.0.1:8000/health | jq

# 10. Monitor logs for model switching
tail -f /home/flintx/peacock/logs/response-*.txt