#!/usr/bin/env python3
"""
peamcp.py - Enhanced with Session Sync & Debug Logging
Drop dimes version with all the fixes baked in
"""

import http.server
import socketserver
import json
import os
import sys
import argparse
import datetime
import re
import random
import subprocess
from pathlib import Path

# --- ENHANCED SESSION MANAGER ---
class PeacockSessionManager:
    """Centralized session management - keeps timestamps synced"""
    
    def __init__(self):
        self.session_file = Path("/home/flintx/peacock/session.json")
        self.logs_dir = Path("/home/flintx/peacock/logs")
        self.html_dir = Path("/home/flintx/peacock/html")
        
        # Ensure directories exist
        self.logs_dir.mkdir(exist_ok=True)
        self.html_dir.mkdir(exist_ok=True)
    
    def get_or_create_session(self):
        """Get existing session or create new one"""
        if self.session_file.exists():
            try:
                with open(self.session_file, 'r') as f:
                    session_data = json.load(f)
                
                # Check if session is recent (within 30 minutes)
                session_time = datetime.datetime.fromisoformat(session_data['created'])
                now = datetime.datetime.now()
                
                if (now - session_time).total_seconds() < 1800:  # 30 minutes
                    return session_data['timestamp']
                    
            except (json.JSONDecodeError, KeyError, ValueError):
                pass
        
        # Create new session
        now = datetime.datetime.now()
        week = now.isocalendar()[1]
        day = now.day
        hour = now.hour
        minute = now.minute
        timestamp = f"{week}-{day}-{hour}{minute:02d}"
        
        session_data = {
            'timestamp': timestamp,
            'created': now.isoformat(),
            'files': {
                'dashboard': f"1prompt-dashboard-{timestamp}.html",
                'xedit': f"xedit-{timestamp}.html",
                'prompt_log': f"promptlog-{timestamp}.txt",
                'response_log': f"response-{timestamp}.txt",
                'mcp_log': f"mcplog-{timestamp}.txt",
                'debug_log': f"debug-{timestamp}.txt"
            }
        }
        
        with open(self.session_file, 'w') as f:
            json.dump(session_data, f, indent=2)
        
        return timestamp

# --- ENHANCED LOGGER ---
class PeacockLogger:
    """Enhanced logging with proper debugging"""
    
    def __init__(self, session_timestamp, enabled=True):
        self.session = session_timestamp
        self.enabled = enabled
        self.logs_dir = Path("/home/flintx/peacock/logs")
        self.logs_dir.mkdir(exist_ok=True)
        
        # Log file paths
        self.prompt_log = self.logs_dir / f"promptlog-{session_timestamp}.txt"
        self.response_log = self.logs_dir / f"response-{session_timestamp}.txt"
        self.mcp_log = self.logs_dir / f"mcplog-{session_timestamp}.txt"
        self.debug_log = self.logs_dir / f"debug-{session_timestamp}.txt"
        
        # Initialize log files
        for log_file in [self.prompt_log, self.response_log, self.mcp_log, self.debug_log]:
            if not log_file.exists():
                log_file.touch()
    
    def debug(self, component, action, message, data=None):
        """Enhanced debug logging"""
        if not self.enabled:
            return
            
        timestamp = datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]
        
        # Console colors
        colors = {
            "SPARK": "\033[93m", "FALCON": "\033[94m", "EAGLE": "\033[92m",
            "HAWK": "\033[95m", "XEDIT": "\033[96m", "SESSION": "\033[91m",
            "FILE": "\033[97m", "PARSE": "\033[90m", "RESET": "\033[0m"
        }
        
        color = colors.get(component, colors["RESET"])
        reset = colors["RESET"]
        
        debug_line = f"{color}[{timestamp}] 🔍 {component}.{action}: {message}{reset}"
        print(debug_line)
        sys.stdout.flush()
        
        # File logging
        with open(self.debug_log, 'a', encoding='utf-8') as f:
            f.write(f"[{timestamp}] {component}.{action}: {message}\n")
            if data:
                f.write(f"DATA: {str(data)[:500]}...\n")
            f.write("-" * 80 + "\n")
    
    def log_prompt(self, stage, model, prompt):
        """Log prompts with model info"""
        if not self.enabled:
            return
            
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        
        with open(self.prompt_log, 'a', encoding='utf-8') as f:
            f.write(f"[{timestamp}] {stage.upper()} → {model}\n")
            f.write("=" * 80 + "\n")
            f.write(f"PROMPT LENGTH: {len(prompt)} chars\n")
            f.write("-" * 40 + "\n")
            f.write(prompt)
            f.write("\n" + "=" * 80 + "\n\n")
    
    def log_response(self, stage, model, response, success=True):
        """Log responses with success status"""
        if not self.enabled:
            return
            
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        status = "SUCCESS" if success else "FAILED"
        
        with open(self.response_log, 'a', encoding='utf-8') as f:
            f.write(f"[{timestamp}] {stage.upper()} ← {model} ({status})\n")
            f.write("=" * 80 + "\n")
            f.write(f"RESPONSE LENGTH: {len(response)} chars\n")
            f.write("-" * 40 + "\n")
            f.write(response)
            f.write("\n" + "=" * 80 + "\n\n")

# --- CONFIGURATION ---
HOST = "127.0.0.1"
PORT = 8000
PROCESS_PATH = "/process"

# GROQ CONFIG
GROQ_API_KEY = "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"

# MULTI-MODEL STRATEGY
PEACOCK_MODEL_STRATEGY = {
    "primary_model": "gemma2-9b-it",
    "speed_model": "llama3-8b-8192",
    "explanation_model": "llama3-8b-8192",
    "json_model": "llama3-8b-8192",
    "fallback_model": "llama-3.1-8b-instant"
}

PEACOCK_STAGE_MODELS = {
    "spark_analysis": "gemma2-9b-it",
    "falcon_architecture": "gemma2-9b-it", 
    "eagle_implementation": "llama3-8b-8192",
    "hawk_qa": "gemma2-9b-it",
    "code_analysis": "llama3-8b-8192"
}

GROQ_CONFIG = {
    "temperature": 0.3,
    "max_tokens": 1024,
    "top_p": 0.8,
    "use_json_mode": False
}

# GLOBAL VARS
LOGGING_ENABLED = False
SESSION_TIMESTAMP = ""
logger = None

def init_logging():
    """Initialize enhanced logging system"""
    global SESSION_TIMESTAMP, logger
    
    session_manager = PeacockSessionManager()
    SESSION_TIMESTAMP = session_manager.get_or_create_session()
    logger = PeacockLogger(SESSION_TIMESTAMP, LOGGING_ENABLED)
    
    if LOGGING_ENABLED:
        logger.debug("SESSION", "init", f"Session initialized: {SESSION_TIMESTAMP}")
        logger.debug("SESSION", "files", f"Logs: /home/flintx/peacock/logs/")

def select_optimal_model(command, priority="balanced"):
    """Select best model based on task"""
    if priority == "speed":
        return PEACOCK_MODEL_STRATEGY["speed_model"]
    elif priority == "structure":
        return "gemma2-9b-it"
    
    return PEACOCK_STAGE_MODELS.get(command, PEACOCK_MODEL_STRATEGY["primary_model"])

def validate_response_quality(response_content, command):
    """Validate response quality"""
    if len(response_content.strip()) < 50: 
        return False
    if command == "eagle_implementation": 
        return "```" in response_content or "filename:" in response_content
    return True

def debug_xedit_generation(eagle_response):
    """Debug XEdit generation step by step"""
    logger.debug("XEDIT", "start", "Starting XEdit generation")
    
    # 1. Extract code blocks
    code_blocks = re.findall(r'```[\w]*\n(.*?)\n```', eagle_response, re.DOTALL)
    logger.debug("XEDIT", "code_blocks", f"Found {len(code_blocks)} code blocks")
    
    if not code_blocks:
        logger.debug("XEDIT", "no_code", "❌ NO CODE BLOCKS FOUND")
        logger.debug("XEDIT", "eagle_sample", f"EAGLE sample: {eagle_response[:200]}...")
        return None
    
    # 2. Combine code
    combined_code = "\n\n".join(code_blocks)
    logger.debug("XEDIT", "combined", f"Combined code: {len(combined_code)} chars")
    
    # 3. Parse functions/classes
    function_patterns = [
        r'def\s+(\w+)\s*\(',  # Python
        r'function\s+(\w+)\s*\(',  # JavaScript  
        r'fn\s+(\w+)\s*\(',  # Rust
        r'func\s+(\w+)\s*\(',  # Go
    ]
    
    class_patterns = [
        r'class\s+(\w+)',  # Python/JS
        r'struct\s+(\w+)',  # Rust/C++
    ]
    
    functions_found = []
    classes_found = []
    
    lines = combined_code.split('\n')
    for i, line in enumerate(lines, 1):
        # Check functions
        for pattern in function_patterns:
            match = re.search(pattern, line)
            if match:
                functions_found.append({
                    "name": match.group(1),
                    "line": i,
                    "type": "function"
                })
        
        # Check classes
        for pattern in class_patterns:
            match = re.search(pattern, line)
            if match:
                classes_found.append({
                    "name": match.group(1), 
                    "line": i,
                    "type": "class"
                })
    
    logger.debug("PARSE", "functions", f"Found {len(functions_found)} functions")
    logger.debug("PARSE", "classes", f"Found {len(classes_found)} classes")
    
    # 4. Generate XEdit paths
    all_items = functions_found + classes_found
    xedit_paths = {}
    
    for idx, item in enumerate(all_items, 1):
        xedit_id = f"7x{idx:03d}"
        xedit_paths[xedit_id] = {
            "display_name": item["name"],
            "type": item["type"],
            "line": item["line"]
        }
    
    logger.debug("XEDIT", "paths", f"Generated {len(xedit_paths)} XEdit-Paths")
    
    return {
        "code_content": combined_code,
        "xedit_paths": xedit_paths,
        "functions": functions_found,
        "classes": classes_found
    }

def generate_xedit_interface_with_debug(xedit_data, project_name):
    """Generate XEdit interface with debug data"""
    if not xedit_data:
        logger.debug("XEDIT", "no_data", "No XEdit data to generate interface")
        return "<html><body><h1>No XEdit data available</h1></body></html>"
    
    code_content = xedit_data["code_content"]
    xedit_paths = xedit_data["xedit_paths"]
    
    # Build functions list HTML
    functions_html = ""
    for xedit_id, data in xedit_paths.items():
        icon = "🏗️" if data["type"] == "class" else "⚡"
        functions_html += f"""
        <div class="function-item" onclick="highlightFunction('{xedit_id}')">
            <div class="function-info">
                <span class="function-icon">{icon}</span>
                <span class="function-name">{data['display_name']}()</span>
                <span class="function-type">{data['type']}</span>
            </div>
            <button class="add-btn" onclick="addToPayload('{xedit_id}')" title="Add to payload">+</button>
        </div>"""
    
    # Format code with line numbers
    code_lines = code_content.split('\n')
    code_html = ""
    for i, line in enumerate(code_lines, 1):
        escaped_line = line.replace('<', '&lt;').replace('>', '&gt;')
        code_html += f'<div class="code-line" data-line="{i}"><span class="line-number">{i:2d}</span><span class="line-content">{escaped_line}</span></div>\n'
    
    # Generate complete HTML interface
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🦚 Peacock XEdit Interface (Debug Enhanced)</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'SF Mono', monospace; background: #0d1117; color: #e6edf3; height: 100vh; overflow: hidden; }}
        .header {{ background: #161b22; border-bottom: 1px solid #30363d; padding: 12px 20px; display: flex; justify-content: space-between; align-items: center; }}
        .peacock-logo {{ font-size: 18px; font-weight: bold; color: #ff6b35; }}
        .session-info {{ background: rgba(0, 255, 136, 0.1); border: 1px solid #00ff88; border-radius: 6px; padding: 4px 8px; font-size: 12px; color: #00ff88; }}
        .debug-badge {{ background: rgba(255, 107, 53, 0.1); border: 1px solid #ff6b35; border-radius: 6px; padding: 4px 8px; font-size: 12px; color: #ff6b35; margin-left: 8px; }}
        .main-container {{ display: flex; height: calc(100vh - 60px); }}
        .left-panel {{ width: 320px; background: #161b22; border-right: 1px solid #30363d; display: flex; flex-direction: column; }}
        .panel-header {{ background: #21262d; padding: 12px 16px; border-bottom: 1px solid #30363d; font-weight: 600; font-size: 13px; color: #7c3aed; }}
        .functions-list {{ flex: 1; overflow-y: auto; padding: 8px; }}
        .function-item {{ background: #21262d; border: 1px solid #30363d; border-radius: 6px; padding: 12px; margin-bottom: 8px; cursor: pointer; transition: all 0.2s; position: relative; }}
        .function-item:hover {{ border-color: #ff6b35; background: #2d333b; transform: translateX(3px); }}
        .function-info {{ display: flex; align-items: center; gap: 8px; }}
        .function-name {{ font-weight: 600; color: #79c0ff; }}
        .function-type {{ background: #30363d; color: #8b949e; padding: 2px 6px; border-radius: 3px; font-size: 10px; text-transform: uppercase; }}
        .add-btn {{ position: absolute; top: 8px; right: 8px; background: #238636; border: none; color: white; width: 24px; height: 24px; border-radius: 4px; cursor: pointer; font-size: 14px; opacity: 0; transition: opacity 0.2s; }}
        .function-item:hover .add-btn {{ opacity: 1; }}
        .middle-panel {{ width: 340px; background: #161b22; border-right: 1px solid #30363d; display: flex; flex-direction: column; }}
        .payload-header {{ background: #238636; color: white; padding: 12px 16px; font-weight: 600; font-size: 14px; text-align: center; }}
        .payload-container {{ flex: 1; padding: 16px; display: flex; flex-direction: column; }}
        .payload-list {{ flex: 1; background: #21262d; border: 1px solid #30363d; border-radius: 8px; padding: 16px; margin-bottom: 16px; overflow-y: auto; min-height: 200px; }}
        .payload-empty {{ color: #6e7681; text-align: center; font-style: italic; margin-top: 50px; }}
        .payload-item {{ background: #2d333b; border: 1px solid #30363d; border-radius: 6px; padding: 12px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center; }}
        .xedit-id {{ font-family: 'SF Mono', monospace; background: #30363d; color: #ff6b35; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }}
        .remove-btn {{ background: #da3633; border: none; color: white; width: 20px; height: 20px; border-radius: 3px; cursor: pointer; font-size: 12px; }}
        .send-button {{ width: 100%; background: #238636; border: none; color: white; padding: 15px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.2s; }}
        .send-button:disabled {{ background: #30363d; color: #8b949e; cursor: not-allowed; }}
        .right-panel {{ flex: 1; background: #0d1117; display: flex; flex-direction: column; }}
        .code-header {{ background: #21262d; padding: 12px 16px; border-bottom: 1px solid #30363d; font-weight: 600; font-size: 13px; color: #f0883e; }}
        .code-container {{ flex: 1; overflow: auto; padding: 16px; }}
        .code-content {{ background: #161b22; border: 1px solid #30363d; border-radius: 6px; padding: 16px; font-family: 'SF Mono', monospace; font-size: 13px; line-height: 1.6; }}
        .code-line {{ display: flex; min-height: 20px; }}
        .code-line.highlighted {{ background: #2d333b; border-left: 3px solid #ff6b35; padding-left: 13px; }}
        .line-number {{ color: #6e7681; user-select: none; margin-right: 16px; min-width: 30px; text-align: right; }}
        .line-content {{ color: #e6edf3; flex: 1; }}
    </style>
</head>
<body>
    <div class="header">
        <div class="peacock-logo">🦚 Peacock XEdit Interface</div>
        <div>
            Project: {project_name} • Session: <span class="session-info">{SESSION_TIMESTAMP}</span>
            <span class="debug-badge">Debug Enhanced</span>
        </div>
    </div>

    <div class="main-container">
        <div class="left-panel">
            <div class="panel-header">📋 Functions & Classes ({len(xedit_paths)} found)</div>
            <div class="functions-list">
                {functions_html}
            </div>
        </div>

        <div class="middle-panel">
            <div class="payload-header">XEdit Payload</div>
            <div class="payload-container">
                <div class="payload-list" id="payload-list">
                    <div class="payload-empty">Click functions to add XEdit-Paths</div>
                </div>
                <button class="send-button" id="send-button" onclick="sendToOptimizedLLM()" disabled>
                    🚀 Send 0 to LLM2
                </button>
            </div>
        </div>

        <div class="right-panel">
            <div class="code-header">📁 {project_name}: Generated Code ({len(code_lines)} lines)</div>
            <div class="code-container">
                <div class="code-content">
                    {code_html}
                </div>
            </div>
        </div>
    </div>

    <script>
        const xeditPaths = {json.dumps(xedit_paths)};
        const sessionTimestamp = '{SESSION_TIMESTAMP}';
        
        function highlightFunction(xeditId) {{
            document.querySelectorAll('.code-line').forEach(line => {{
                line.classList.remove('highlighted');
            }});
            
            document.querySelectorAll('.function-item').forEach(item => {{
                item.classList.remove('selected');
            }});
            
            event.currentTarget.classList.add('selected');
            
            const pathData = xeditPaths[xeditId];
            if (pathData && pathData.line) {{
                const lineNum = pathData.line;
                const line = document.querySelector(`[data-line="${{lineNum}}"]`);
                if (line) {{
                    line.classList.add('highlighted');
                    line.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
                }}
            }}
        }}

        function addToPayload(xeditId) {{
            const payloadList = document.getElementById("payload-list");
            const sendButton = document.getElementById("send-button");
            
            if (document.getElementById(`payload-${{xeditId}}`)) {{
                return;
            }}
            
            const emptyMsg = payloadList.querySelector('.payload-empty');
            if (emptyMsg) {{
                emptyMsg.remove();
            }}
            
            const pathData = xeditPaths[xeditId];
            const payloadItem = document.createElement("div");
            payloadItem.className = "payload-item";
            payloadItem.id = `payload-${{xeditId}}`;
            payloadItem.innerHTML = `
                <div>
                    <span class="xedit-id">${{xeditId}}</span>
                    <span style="color: #8b949e; font-size: 12px; margin-left: 8px;">${{pathData.display_name}}()</span>
                </div>
                <button class="remove-btn" onclick="removeFromPayload('${{xeditId}}')">&times;</button>
            `;
            
            payloadList.appendChild(payloadItem);
            
            const count = payloadList.children.length;
            sendButton.textContent = `🚀 Send ${{count}} to LLM2`;
            sendButton.disabled = false;
        }}

        function removeFromPayload(xeditId) {{
            const payloadItem = document.getElementById(`payload-${{xeditId}}`);
            if (payloadItem) {{
                payloadItem.remove();
            }}
            
            const payloadList = document.getElementById("payload-list");
            const sendButton = document.getElementById("send-button");
            const count = payloadList.children.length;
            
            if (count === 0) {{
                payloadList.innerHTML = '<div class="payload-empty">Click functions to add XEdit-Paths</div>';
                sendButton.textContent = "🚀 Send 0 to LLM2";
                sendButton.disabled = true;
            }} else {{
                sendButton.textContent = `🚀 Send ${{count}} to LLM2`;
            }}
        }}

        function sendToOptimizedLLM() {{
            const payloadItems = document.querySelectorAll('.payload-item');
            const xeditIds = Array.from(payloadItems).map(item => {{
                return item.querySelector('.xedit-id').textContent;
            }});
            
            console.log('Sending XEdit-Paths to LLM2:', xeditIds);
            
            fetch('http://127.0.0.1:8000/process', {{
                method: 'POST',
                headers: {{ 'Content-Type': 'application/json' }},
                body: JSON.stringify({{
                    command: 'fix_xedit_paths',
                    xedit_paths: xeditIds,
                    session: sessionTimestamp
                }})
            }})
            .then(response => response.json())
            .then(data => {{
                console.log('LLM2 Response:', data);
                if (data.success) {{
                    alert(`✅ LLM2 processed ${{xeditIds.length}} XEdit-Paths!\nModel: ${{data.model_used || 'Auto-selected'}}`);
                }} else {{
                    alert(`❌ Error: ${{data.error}}`);
                }}
            }})
            .catch(error => {{
                console.error('Error:', error);
                alert(`❌ Connection error: ${{error.message}}`);
            }});
        }}
    </script>
</body>
</html>"""
    
    logger.debug("XEDIT", "html_generated", f"Generated HTML interface: {len(html_content)} chars")
    return html_content

def call_optimized_groq(prompt, command):
    """Call Groq with enhanced logging"""
    primary_model = select_optimal_model(command)
    fallback_models = [
        PEACOCK_MODEL_STRATEGY["speed_model"], 
        PEACOCK_MODEL_STRATEGY["fallback_model"]
    ]
    
    models_to_try = [primary_model] + [m for m in fallback_models if m != primary_model]
    
    logger.debug(command.upper(), "start", f"Using {primary_model}")
    logger.log_prompt(command, primary_model, prompt)

    for model in models_to_try:
        try:
            from groq import Groq
            client = Groq(api_key=GROQ_API_KEY)
            
            logger.debug(command.upper(), "api_call", f"Calling {model}...")
            
            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=GROQ_CONFIG["temperature"],
                max_tokens=GROQ_CONFIG["max_tokens"],
                top_p=GROQ_CONFIG["top_p"]
            )
            
            content = response.choices[0].message.content
            
            if validate_response_quality(content, command):
                logger.debug(command.upper(), "success", f"Model: {model}, Length: {len(content)} chars")
                logger.log_response(command, model, content, success=True)
                
                return {
                    "success": True,
                    "text": content,
                    "model_used": model
                }
            else:
                logger.debug(command.upper(), "quality_fail", f"Quality validation failed for {model}")
                
        except Exception as e:
            logger.debug(command.upper(), "error", f"Model {model} failed: {str(e)}")
            continue

    logger.log_response(command, "ALL_MODELS", "ALL MODELS FAILED", success=False)
    return {"success": False, "error": "All models failed", "models_tried": models_to_try}

def run_peacock_pipeline(user_request):
    """Run complete pipeline with enhanced debugging"""
    logger.debug("PIPELINE", "start", f"Starting pipeline for: {user_request[:50]}...")
    
    pipeline_results = {}
    
    # STAGE 1: SPARK
    spark_prompt = f"""Act as Spark, a strategic requirements analyst. Analyze this project idea:

Project: {user_request}

Provide analysis in this EXACT format:

**1. Core Objective:**
[One clear sentence describing the main goal]

**2. Current State:**
[Current situation/problems this solves]

**3. Target State:**
[Desired end state after implementation]

**4. In Scope:**
- [Feature 1]
- [Feature 2] 
- [Feature 3]

**5. Out of Scope:**
- [What's NOT included]
- [Future considerations]

Then provide the structured data as JSON:
```json
{{
    "core_objective": "string",
    "current_state": "string",
    "target_state": "string", 
    "in_scope": ["list"],
    "out_of_scope": ["list"],
    "confidence_score": 8
}}
```

Keep it strategic and concise."""
    
    spark_response = call_optimized_groq(spark_prompt, "spark_analysis")
    
    if not spark_response.get("success"):
        logger.debug("PIPELINE", "spark_fail", f"SPARK failed: {spark_response}")
        return {"error": "Spark stage failed", "stage": "SPARK", "details": spark_response}
    
    pipeline_results["spark"] = spark_response
    
    # STAGE 2: FALCON
    falcon_prompt = f"""Act as Falcon, a senior software architect. Design the technical architecture for this project.

Requirements Analysis:
{spark_response['text']}

Provide architecture design in this EXACT format:

**TECHNOLOGY STACK:**
- Frontend: [Technology choices]
- Backend: [Technology choices]  
- Database: [Technology choices]
- Additional: [Other technologies]

**CORE COMPONENTS:**
1. [Component Name] - [Purpose and functionality]
2. [Component Name] - [Purpose and functionality]
3. [Component Name] - [Purpose and functionality]

**FILE STRUCTURE:**
```
project_root/
├── [folder1]/
│   ├── [file1.ext]
│   └── [file2.ext]
├── [folder2]/
└── [file3.ext]
```

**COMPONENT INTERACTIONS:**
[Describe how components communicate and data flows]

Then provide the structured data as JSON:
```json
{{
    "tech_stack": {{
        "frontend": "string",
        "backend": "string",
        "database": "string"
    }},
    "components": ["list"],
    "complexity": "simple|moderate|complex",
    "confidence_score": 8
}}
```

Focus on practical, implementable architecture."""
    
    falcon_response = call_optimized_groq(falcon_prompt, "falcon_architecture")
    
    if not falcon_response.get("success"):
        logger.debug("PIPELINE", "falcon_fail", f"FALCON failed: {falcon_response}")
        return {"error": "Falcon stage failed", "stage": "FALCON", "details": falcon_response}
    
    pipeline_results["falcon"] = falcon_response
    
    # STAGE 3: EAGLE
    eagle_prompt = f"""Act as Eagle, a senior developer. Implement the complete codebase based on this architecture.

Architecture Design:
{falcon_response['text']}

Generate complete, working code for each file specified in the architecture.

Format each file as:

**filename: path/to/file.ext**
```language
[Complete file content]
```

Provide:
- Complete, production-ready code
- Proper error handling
- Clear documentation
- Best practices implementation
- All necessary imports and dependencies

Make it work perfectly from the start."""
    
    eagle_response = call_optimized_groq(eagle_prompt, "eagle_implementation")
    
    if not eagle_response.get("success"):
        logger.debug("PIPELINE", "eagle_fail", f"EAGLE failed: {eagle_response}")
        return {"error": "Eagle stage failed", "stage": "EAGLE", "details": eagle_response}
    
    pipeline_results["eagle"] = eagle_response
    
    # STAGE 4: HAWK
    hawk_prompt = f"""Act as Hawk, a quality assurance specialist. Create comprehensive QA strategy for this implementation.

Implementation Details:
{eagle_response['text']}

Provide QA strategy in this EXACT format:

**1. Test Cases:**
- Functional tests for core features
- Edge cases and error scenarios
- Integration test requirements

**2. Security Validation:**
- Authentication/authorization checks
- Input validation requirements
- Data protection measures

**3. Performance Considerations:**
- Load testing requirements
- Scalability checkpoints
- Resource optimization

**4. Error Handling Scenarios:**
- Network failure handling
- Data corruption recovery
- User error management

**5. Production Readiness Checklist:**
- Deployment requirements
- Monitoring setup
- Backup strategies

Then provide the structured data as JSON:
```json
{{
    "test_coverage": 85,
    "security_score": 9,
    "performance_rating": "good",
    "production_ready": true,
    "confidence_score": 8
}}
```

Be specific and actionable for each area."""
    
    hawk_response = call_optimized_groq(hawk_prompt, "hawk_qa")
    
    if not hawk_response.get("success"):
        logger.debug("PIPELINE", "hawk_fail", f"HAWK failed: {hawk_response}")
        return {"error": "Hawk stage failed", "stage": "HAWK", "details": hawk_response}
    
    pipeline_results["hawk"] = hawk_response
    
    # STAGE 5: XEDIT GENERATION WITH ENHANCED DEBUGGING
    logger.debug("XEDIT", "pipeline_complete", "Pipeline complete, generating XEdit interface")
    
    xedit_data = debug_xedit_generation(eagle_response['text'])
    
    if xedit_data:
        html_content = generate_xedit_interface_with_debug(xedit_data, user_request)
        
        # Save XEdit file
        html_dir = Path("/home/flintx/peacock/html")
        html_dir.mkdir(exist_ok=True)
        output_path = html_dir / f"xedit-{SESSION_TIMESTAMP}.html"
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.debug("XEDIT", "file_saved", f"XEdit saved: {output_path}")
        xedit_success = True
    else:
        logger.debug("XEDIT", "generation_failed", "XEdit generation failed - no data")
        xedit_success = False
    
    logger.debug("PIPELINE", "complete", f"Pipeline completed successfully")
    
    return {
        "success": True,
        "pipeline_results": pipeline_results,
        "xedit_generated": xedit_success,
        "session": SESSION_TIMESTAMP,
        "xedit_data": xedit_data
    }

# --- HTTP SERVER ---
class PeacockRequestHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        """Override to use enhanced logging"""
        if logger:
            logger.debug("HTTP", "request", format % args)

    def do_GET(self):
        if self.path == "/":
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>🦚 Peacock MCP Server - Debug Enhanced</title>
                <style>
                    body {{ font-family: 'JetBrains Mono', monospace; background: #0f0f0f; color: #00ff88; padding: 20px; }}
                    .status {{ background: #1e1e1e; padding: 20px; border-radius: 8px; border: 1px solid #00ff88; }}
                    .debug-info {{ background: #2a2a2a; padding: 15px; margin: 15px 0; border-radius: 6px; border-left: 4px solid #ff6b35; }}
                </style>
            </head>
            <body>
                <h1>🦚 Peacock MCP Server (Debug Enhanced)</h1>
                <div class="status">
                    <h2>✅ Server Status: Online</h2>
                    <p><strong>Session:</strong> {SESSION_TIMESTAMP}</p>
                    <p><strong>Logging:</strong> {'Enabled' if LOGGING_ENABLED else 'Disabled'}</p>
                    <p><strong>Debug Mode:</strong> Enhanced</p>
                </div>
                
                <div class="debug-info">
                    <h3>🔍 Enhanced Debug Features</h3>
                    <p><strong>XEdit Generation:</strong> Step-by-step debugging</p>
                    <p><strong>Function Parsing:</strong> Detailed pattern matching</p>
                    <p><strong>Session Sync:</strong> Timestamp coordination</p>
                    <p><strong>File Links:</strong> Fixed log and XEdit links</p>
                </div>
            </body>
            </html>
            """
            self.wfile.write(html_content.encode("utf-8"))
            
        elif self.path == "/health":
            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            health_data = {
                "status": "healthy", 
                "session": SESSION_TIMESTAMP,
                "logging": LOGGING_ENABLED,
                "debug_mode": "enhanced"
            }
            self.wfile.write(json.dumps(health_data).encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == PROCESS_PATH:
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)

            try:
                received_data = json.loads(post_data.decode('utf-8'))
                
                command = received_data.get('command', 'unknown')
                text_to_process = received_data.get('text', '')
                
                logger.debug("HTTP", "post_received", f"Command: {command}, Text: {text_to_process[:50]}...")
                
                if command == "peacock_full":
                    logger.debug("HTTP", "peacock_start", "Starting full Peacock pipeline")
                    result = run_peacock_pipeline(text_to_process)
                
                elif command == "fix_xedit_paths":
                    xedit_paths = received_data.get('xedit_paths', [])
                    logger.debug("HTTP", "xedit_paths", f"Processing {len(xedit_paths)} XEdit-Paths")
                    
                    prompt = f"Fix and improve the code at these XEdit-Paths: {', '.join(xedit_paths)}"
                    llm_response = call_optimized_groq(prompt, "code_analysis")
                    
                    if llm_response.get("success"):
                        result = {
                            "success": True,
                            "response": llm_response['text'],
                            "paths_processed": len(xedit_paths),
                            "model_used": llm_response['model_used']
                        }
                    else:
                        result = {"success": False, "error": llm_response.get('error')}
                        
                else:
                    logger.debug("HTTP", "default_processing", f"Processing default command: {command}")
                    prompt = f"Process this request: {text_to_process}"
                    llm_response = call_optimized_groq(prompt, "general")
                    
                    if llm_response.get("success"):
                        result = {
                            "success": True,
                            "response": llm_response['text'],
                            "model_used": llm_response['model_used']
                        }
                    else:
                        result = {"success": False, "error": llm_response.get('error')}

                # Send response
                self.send_response(200)
                self.send_header("Content-type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                
                response_json = json.dumps(result, indent=2)
                self.wfile.write(response_json.encode("utf-8"))
                
                logger.debug("HTTP", "response_sent", f"Response sent: {len(response_json)} bytes")

            except Exception as e:
                logger.debug("HTTP", "error", f"Server error: {str(e)}")
                self.send_response(500)
                self.send_header("Content-type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                error_response = {"success": False, "error": f"Server error: {str(e)}"}
                self.wfile.write(json.dumps(error_response).encode("utf-8"))

        else:
            self.send_response(404)
            self.end_headers()

    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

def main():
    """Main function with enhanced debugging"""
    global LOGGING_ENABLED, PORT
    
    parser = argparse.ArgumentParser(description='🦚 Peacock MCP Server - Debug Enhanced')
    parser.add_argument('--log', '-l', action='store_true', help='Enable enhanced logging')
    parser.add_argument('--port', '-p', type=int, default=8000, help='Server port (default: 8000)')
    
    args = parser.parse_args()
    
    LOGGING_ENABLED = args.log
    PORT = args.port
    
    # Initialize enhanced logging
    init_logging()
    
    print("🦚" + "="*60 + "🦚")
    print("    PEACOCK MCP SERVER - DEBUG ENHANCED")
    print("🦚" + "="*60 + "🦚")
    print(f"🔥 Session: {SESSION_TIMESTAMP}")
    print(f"🔍 Debug Logging: {'Enabled' if LOGGING_ENABLED else 'Disabled'}")
    print(f"🌐 Server: http://127.0.0.1:{PORT}")
    print("="*70)
    
    if LOGGING_ENABLED:
        print("📁 ENHANCED LOG FILES:")
        print(f"   Debug: /home/flintx/peacock/logs/debug-{SESSION_TIMESTAMP}.txt")
        print(f"   Prompts: /home/flintx/peacock/logs/promptlog-{SESSION_TIMESTAMP}.txt")
        print(f"   Responses: /home/flintx/peacock/logs/response-{SESSION_TIMESTAMP}.txt")
        print(f"   HTTP: /home/flintx/peacock/logs/mcplog-{SESSION_TIMESTAMP}.txt")
        print()
    
    try:
        with socketserver.TCPServer((HOST, PORT), PeacockRequestHandler) as httpd:
            logger.debug("SERVER", "start", f"Server started on port {PORT}")
            httpd.serve_forever()
    except KeyboardInterrupt:
        logger.debug("SERVER", "stop", "Server stopped by user")
        print("\n🛑 Server stopped by user")
    except Exception as e:
        logger.debug("SERVER", "error", f"Server error: {str(e)}")
        print(f"❌ Server error: {e}")

if __name__ == "__main__":
    main()