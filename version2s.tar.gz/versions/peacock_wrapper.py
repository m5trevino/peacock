#!/usr/bin/env python3
"""
Peacock Wrapper - Launch the complete Peacock ecosystem
Usage: python peacock.py [--auto] [--mcp-only] [--dashboard-only]
"""

import subprocess
import time
import sys
import os
import argparse
import requests
from pathlib import Path

def cli_status(stage, status, message=""):
    """Simple status output"""
    colors = {
        "INFO": "\033[94m",
        "WORKING": "\033[93m", 
        "SUCCESS": "\033[92m",
        "ERROR": "\033[91m",
        "RESET": "\033[0m"
    }
    
    icons = {
        "INFO": "ℹ️",
        "WORKING": "⚙️",
        "SUCCESS": "✅", 
        "ERROR": "❌"
    }
    
    color = colors.get(status, "")
    icon = icons.get(status, "🔄")
    reset = colors["RESET"]
    
    print(f"{color}{icon} {stage}: {message}{reset}")

def check_server_running():
    """Check if MCP server is already running"""
    try:
        response = requests.get("http://127.0.0.1:8000/health", timeout=3)
        return response.status_code == 200
    except:
        return False

def start_mcp_server():
    """Start the MCP server in background"""
    cli_status("MCP SERVER", "WORKING", "Starting Peacock MCP server...")
    
    try:
        # Start peamcp.py with logging
        process = subprocess.Popen([
            sys.executable, "peamcp.py", "--log"
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Wait a bit for server to start
        time.sleep(3)
        
        # Check if it's running
        if check_server_running():
            cli_status("MCP SERVER", "SUCCESS", "Server online at http://127.0.0.1:8000")
            return process
        else:
            cli_status("MCP SERVER", "ERROR", "Server failed to start")
            return None
            
    except Exception as e:
        cli_status("MCP SERVER", "ERROR", f"Failed to start: {e}")
        return None

def launch_dashboard():
    """Launch the 1prompt dashboard"""
    cli_status("1PROMPT DASHBOARD", "WORKING", "Launching dashboard generator...")
    
    try:
        # Run 1prompt.py
        result = subprocess.run([sys.executable, "1prompt.py"], 
                              capture_output=False, check=True)
        cli_status("1PROMPT DASHBOARD", "SUCCESS", "Dashboard launched successfully")
        return True
    except subprocess.CalledProcessError as e:
        cli_status("1PROMPT DASHBOARD", "ERROR", f"Failed to launch: {e}")
        return False
    except FileNotFoundError:
        cli_status("1PROMPT DASHBOARD", "ERROR", "1prompt.py not found")
        return False

def show_peacock_banner():
    """Show Peacock startup banner"""
    print("🦚" + "="*68 + "🦚")
    print("    PEACOCK ECOSYSTEM LAUNCHER")
    print("🦚" + "="*68 + "🦚")
    print()
    print("🔥 Components:")
    print("   📡 peamcp.py  - MCP Server (API)")
    print("   🎯 1prompt.py - Dashboard Generator") 
    print("   ✏️  xedit.py   - Code Interface Generator")
    print()

def show_usage_info():
    """Show usage information"""
    print("🚀 PEACOCK ECOSYSTEM READY!")
    print()
    print("📋 What's Running:")
    print("   ✅ MCP Server: http://127.0.0.1:8000")
    print("   ✅ 1Prompt Dashboard: Auto-opened in browser")
    print()
    print("🎯 How to Use:")
    print("   1. Type your project idea in the dashboard")
    print("   2. Click '🚀 Build Project'")
    print("   3. Watch the live pipeline progress")
    print("   4. XEdit interface auto-opens when done")
    print()
    print("🛑 To Stop:")
    print("   Press Ctrl+C to stop all components")
    print("="*70)

def main():
    """Main wrapper function"""
    parser = argparse.ArgumentParser(description='🦚 Peacock Ecosystem Launcher')
    parser.add_argument('--auto', action='store_true', 
                       help='Auto-start everything (default)')
    parser.add_argument('--mcp-only', action='store_true',
                       help='Start only MCP server')
    parser.add_argument('--dashboard-only', action='store_true',
                       help='Start only dashboard (assumes MCP running)')
    
    args = parser.parse_args()
    
    show_peacock_banner()
    
    # Check current directory for required files
    required_files = ['peamcp.py', '1prompt.py', 'xedit.py']
    missing_files = [f for f in required_files if not Path(f).exists()]
    
    if missing_files:
        cli_status("SETUP", "ERROR", f"Missing files: {', '.join(missing_files)}")
        print("Make sure you're in the /home/flintx/peacock/core directory")
        return 1
    
    mcp_process = None
    
    try:
        if args.dashboard_only:
            # Just launch dashboard
            cli_status("MODE", "INFO", "Dashboard-only mode")
            if not check_server_running():
                cli_status("MCP SERVER", "ERROR", "MCP server not running! Start with --mcp-only first")
                return 1
            launch_dashboard()
            
        elif args.mcp_only:
            # Just start MCP server
            cli_status("MODE", "INFO", "MCP-only mode")
            mcp_process = start_mcp_server()
            if mcp_process:
                print("\n🦚 MCP Server running. Press Ctrl+C to stop.")
                mcp_process.wait()
            
        else:
            # Full auto mode (default)
            cli_status("MODE", "INFO", "Full auto mode - starting complete ecosystem")
            
            # Check if MCP server already running
            if check_server_running():
                cli_status("MCP SERVER", "INFO", "Server already running")
            else:
                mcp_process = start_mcp_server()
                if not mcp_process:
                    return 1
            
            # Launch dashboard
            launch_dashboard()
            
            # Show usage info
            show_usage_info()
            
            # Keep MCP server running if we started it
            if mcp_process:
                try:
                    print("🔄 Keeping MCP server alive... Press Ctrl+C to stop all")
                    mcp_process.wait()
                except KeyboardInterrupt:
                    cli_status("SHUTDOWN", "INFO", "Stopping Peacock ecosystem...")
                    mcp_process.terminate()
                    mcp_process.wait()
    
    except KeyboardInterrupt:
        cli_status("SHUTDOWN", "INFO", "Shutting down...")
        if mcp_process:
            mcp_process.terminate()
            mcp_process.wait()
        return 0
    except Exception as e:
        cli_status("ERROR", "ERROR", f"Unexpected error: {e}")
        if mcp_process:
            mcp_process.terminate()
        return 1

if __name__ == "__main__":
    sys.exit(main())