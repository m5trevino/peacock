Java.perform(() => {
    const Activity = Java.use("android.app.Activity");
    Activity.getWindow.implementation = function () {
        this.setFlags(0, 128); // Disable SECURE flag
        return this.getWindow();
    };
    console.log("SECURE flag disabled.");
});
